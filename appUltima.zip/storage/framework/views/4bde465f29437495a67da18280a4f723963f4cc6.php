<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="card">
        <div class="card-header font-bold text-xl"><?php echo e($empresa->razon_social); ?>: Cargar productos</div>
        <div class="card-body">

            <?php if(isset($status)): ?>
            <div class="row">
              <div class="alert alert-danger">
                <?php $__currentLoopData = $status["errors"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e(_("Error en la fila: ". $error["sku"])); ?>

                  <br/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-6">
                    <div class="container">
                        <div class="d-flex flex-column">
                            <strong>Descarga el formato de carga masiva de productos</strong>
                            <a class="btn btn-info" href="<?php echo e(asset("storage/formatos/productos.xlsx")); ?>" target="_BLANK">Aqui</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="container">
                        <form method="POST" action="<?php echo e(route('empresas.productos.store', $empresa)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-row">
                                <label for="">Ingrese el Archivo:</label>
                                <input name="productos" type="file" class="form-control" />
                            </div>

                            <div class="form-row mt-3">
                                <button class="btn btn-primary" type="submit">Cargar</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jmonagas/Projects/mline-siger/resources/views/control/productos/create.blade.php ENDPATH**/ ?>