<?php $__env->startSection('title', 'Factura Electronica | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
<?php $__env->startSection('home-route', route('compass.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="card">
        <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Control de Factura Electronica</h3>
        <div class="card-body">
            <div class="container mt-2">
                <header class="d-flex flex-row justify-content-end my-2">
                    <form method="POST" action="<?php echo e(route("factura_electronica_export", $cierre)); ?>" class="mr-3">
                        <?php echo csrf_field(); ?>

                        <button class="btn btn-info">Exportar a Excel</button>
                    </form>
                    <?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
                    <a class="btn btn-outline-success" href="<?php echo e(route("factura_electronica_create", $cierre)); ?>">Crear FE</a>
                    <?php endif; ?>
                </header>
                <table class="table table-sm" id="datatable">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Folio</th>
                            <th>Monto</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($factura->fecha); ?></td>
                            <td><?php echo e($factura->folio); ?></td>
                            <td>$ <?php echo e(number_format($factura->monto, 0)); ?></td>
                            <td>
                                <div class="d-inline-flex justify-content-around">
                                    <a href="<?php echo e(asset($factura->documento)); ?>" target="_BLANK">Ver PDF</a>
                                    <?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
                                    <a href="<?php echo e(route("factura_electronica_edit", $factura)); ?>" class="btn btn-warning mx-2">Editar</a>
                                    <form method="POST" action="<?php echo e(route('factura_electronica_delete', $factura)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field("DELETE"); ?>

                                        <button class="btn btn-danger deleteBtn" type="submit">Eliminar</button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
<script type="text/javascript">
    $(".deleteBtn").click((event) => {
        if (!confirm("Confirme si desea eliminar este documento")) {
            event.preventDefault();
        };
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/factura_electronica/cierre.blade.php ENDPATH**/ ?>