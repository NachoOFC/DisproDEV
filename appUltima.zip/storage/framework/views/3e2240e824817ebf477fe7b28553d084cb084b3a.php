<?php $__env->startSection('title', 'Recibir Orden de Pedido | Mline Viveres'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="card">
    <h3 class="card-header font-bold text-xl">
        <?php echo e(Auth::user()->userable->nombre); ?>: Recibir Orden de Pedido
    </h3>
    <div class="card-body">
        <div class="row justify-content-center align-items-center">
            <div class="col-md-12">
                <recepcion-requerimiento-component :guias-despacho='<?php echo json_encode($guiasDespacho, 15, 512) ?>' :observaciones='<?php echo json_encode($observaciones, 15, 512) ?>' store-route="<?php echo e(route("pedidos.recepcion.post", $requerimiento)); ?>">
                </recepcion-requerimiento-component>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/requerimiento/recepcion.blade.php ENDPATH**/ ?>