

<?php $__env->startSection('title', 'Seleccionar Centro | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl">Seleccionar Centro</h3>
            <div class="card-body">
                <form action="<?php echo e(route('presupuesto.editar')); ?>" method="GET">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="centro">Centro:</label>
                        <select class="form-control" id="centro" name="centro" required>
                            <option value="">Seleccione un centro</option>
                            <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($centro->id); ?>"><?php echo e($centro->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="year">Año:</label>
                        <select class="form-control" id="year" name="year" required>
                            <?php for($i = date('Y') - 5; $i <= date('Y') + 5; $i++): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e($i == date('Y') ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="text-center mt-4">
                        <button type="submit" class="btn btn-primary">Continuar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/alogis_dev/resources/views/presupuesto/seleccionar_centro.blade.php ENDPATH**/ ?>