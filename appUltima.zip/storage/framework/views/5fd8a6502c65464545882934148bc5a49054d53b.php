<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
  <div class="container">
    <div class="card">
      <div class="card-header font-bold text-xl">Guias de Despacho</div>
      <div class="card-body">
        <guia-despacho-index :requerimientos='<?php echo json_encode($requerimientos, 15, 512) ?>'></guia-despacho-index>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jmonagas/Projects/mline-siger/resources/views/guia_despacho/index.blade.php ENDPATH**/ ?>