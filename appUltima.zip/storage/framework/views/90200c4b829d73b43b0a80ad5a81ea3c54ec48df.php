<?php $__env->startSection('title', 'Carta de Requerimientos | MLine SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="card">
        <h3 class="card-header font-bold text-xl"> Carta de Trabajo</h3>
        <div class="card-body">
            <div class="d-flex flex-row mb-2">
            </div>
            <div class="container mt-2">
                <form action="<?php echo e(route('reportes.carta.filter')); ?>" method="POST" accept-charset="utf-8">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="form-group col-md-2 d-flex flex-col">
                            <label class="" for="inicio">Fecha de Inicio:</label>
                            <span class="">
                                <input class="form-control" required type="date" name="inicio">
                                <p class="text-muted">Obligatorio</p>
                            </span>
                        </div>

                        <div class="form-group col-md-2 d-flex flex-col">
                            <label class="" for="fin">Fecha de Fin:</label>
                            <span class="">
                                <input class="form-control" required type="date" name="fin">
                                <p class="text-muted">Obligatorio</p>
                            </span>
                        </div>
                    </div>

                    <v-expansion-panels>

                        <v-expansion-panel>
                            <v-expansion-panel-header>Filtrar por Empresas</v-expansion-panel-header>
                            <v-expansion-panel-content>
                                <div class="form-group row">
                                    <label class="col-sm-2" for="empresas">Empresas:</label>
                                    <span class="col-sm-6">
                                        <autoselect :items='<?php echo json_encode($empresas, 15, 512) ?>' item-text="razon_social" item-value="id" name="empresas" :multiple="true"></autoselect>
                                    </span>
                                </div>
                            </v-expansion-panel-content>
                        </v-expansion-panel>

                        <v-expansion-panel>
                            <v-expansion-panel-header>Filtrar por Centros</v-expansion-panel-header>
                            <v-expansion-panel-content>
                                <div class="form-group row">
                                    <label class="col-sm-2" for="centros">Centros:</label>
                                    <span class="col-sm-6">
                                        <autoselect :items='<?php echo json_encode($centros, 15, 512) ?>' item-text="nombre" item-value="id" name="centros" :multiple="true"></autoselect>
                                    </span>
                                </div>
                            </v-expansion-panel-content>
                        </v-expansion-panel>

                        <v-expansion-panel>
                            <v-expansion-panel-header>Filtrar por Zonas</v-expansion-panel-header>
                            <v-expansion-panel-content>
                                <div class="form-group row">
                                    <label class="col-sm-2" for="zonas">Zonas:</label>
                                    <span class="col-sm-6">
                                        <autoselect :items='<?php echo json_encode($zonas, 15, 512) ?>' item-text="nombre" item-value="nombre" name="zonas" :multiple="true"></autoselect>
                                    </span>
                                </div>
                            </v-expansion-panel-content>
                        </v-expansion-panel>
                    </v-expansion-panels>

                    <button type="submit" class="btn bg-orange-500 hover:bg-orange-700 text-white my-5">Ver Historial</button>
                    <button type="submit" name="generate" value="1" class="btn btn-warning mx-2 my-5">Generar Excel Consolidado</button>
                </form>

                <?php if(isset($requerimientos)): ?>
                <?php if($requerimientos->count() > 0): ?>
                <table class="table table-sm" id="datatable">
                    <thead>
                        <tr>
                            <th>Centro</th>
                            <th>Id</th>
                            <th>Requerimiento</th>
                            <th>Fecha</th>
                            <th>Monto</th>
                            <th>Descargar Carta</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $requerimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($requerimiento->centro->nombre); ?></td>
                            <td>

                                <a href="<?php echo e(route('pedidos.show', $requerimiento)); ?>">
                                    <?php echo e($requerimiento->id); ?>

                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(route('pedidos.show', $requerimiento)); ?>">
                                    <?php echo e($requerimiento->nombre); ?>

                                </a>
                            </td>
                            <td><?php echo e($requerimiento->created_at); ?></td>
                            <td><?php echo e(number_format($requerimiento->getTotal(), 0)); ?></td>
                            <td>
                                <form method="POST" action="<?php echo e(route('reportes.carta.download', $requerimiento)); ?>">
                                    <?php echo csrf_field(); ?>

                                    <button class="btn bg-orange-500 hover:bg-orange-700 text-white" type="submit">Descargar Carta</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php endif; ?>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/alogis_dev/resources/views/reporte/historial_requerimientos.blade.php ENDPATH**/ ?>