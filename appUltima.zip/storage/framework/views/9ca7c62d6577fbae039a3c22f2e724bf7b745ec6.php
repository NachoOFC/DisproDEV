<?php $__env->startSection('title', 'Armar Cajas'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>" />
<div class="container">
    <div class="card">
        <h3 class="card-header font-bold text-xl">Armar Cajas</h3>
        <div class="card-body" style="overflow-x: auto;">
            <?php if($centros->count() > 0): ?>
            <a class="btn btn-secondary" style="color: #fff;"  href="<?php echo e(route('compass.home')); ?>"><i class='fas fa-arrow-alt-circle-left'></i></a>


            <tabs>
                <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tab title="<?php echo e($centro->nombre); ?>">
                    <div class="container mt-2">
                        <div class="row mb-2">
                            <div class="col">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-2 text-right">Empresa:</div>
                                            <div class="col-3 font-bold"><?php echo e($centro->empresa->razon_social); ?></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-2 text-right">RUT Empresa:</div>
                                            <div class="col-3 font-bold"><?php echo e($centro->empresa->rut); ?></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-2 text-right">Centro:</div>
                                            <div class="col-3 font-bold"><?php echo e($centro->nombre); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table id="datatable" class="table table-bordered table-sm ">
                                <thead>
                                    <tr>
                                        <th scope="col">Nombre</th>
                                        <th scope="col">Estado</th>
                                        <th scope="col">Accion</th>
                                        <th scope="col">Eliminar</th>
                                        <th scope="col">Armar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $centro
                                    ->requerimientos()
                                    ->where('estado', 'EN BODEGA')
                                    ->where('folio', null)
                                    ->where('transporte_id', null)
                                    ->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('pedidos.show', $requerimiento)); ?>"><?php echo e($requerimiento->nombre); ?></a>
                                        </td>

                                        <td><?php echo e($requerimiento->estado); ?></td>

                                        <td>
                                            <modal-btn-component  title="Orden de Pedido" :message='[
                                                                           { data: <?php echo json_encode($requerimiento->productos, 15, 512) ?>, type: "Array", keys: ["sku", "detalle", "pivot"], pivot: "cantidad"}
                                                                           ]'>Ver Orden de Pedido</modal-btn-component>
                                        </td>
                                        <td>
                                            <form method="POST" action="<?php echo e(route('requerimiento.eliminar', $requerimiento)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field("DELETE"); ?>
                                                <button type="submit" class="btn btn-outline-danger">Eliminar Pedido</button>
                                            </form>
                                        </td>
                                        <td>
                                            <a class="btn btn-blue" href="<?php echo e(route('compass.pedidos.show', $requerimiento)); ?>">Armar Caja</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </tab>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tabs>
            <?php else: ?>
            <div class="alert alert-dark">Sin Ordenes de Pedido pendientes por armar</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/compass/cajas_index.blade.php ENDPATH**/ ?>