<?php $__env->startSection('title', 'Ver Observaciones | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="card">
    <h3 class="card-header font-bold text-xl">
        <?php echo e(Auth::user()->userable->nombre); ?>:
        Productos con Observaciones en Guia de Despachos
    </h3>
    <div class="card-body">
        <div class="row justify-content-center align-items-center">
            <div class="col-md-12">
                <form method="POST" action="<?php echo e(route('rechazos.export', $requerimiento)); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-primary mb-2">Exportar a Excel</button>
                </form>
                <index-component :headers="[
                { text: 'Folio Guia', value: 'guia.folio' },
                { text: 'Detalle', value: 'producto.detalle' },
                { text: 'Despachado', value: 'producto.pivot.real' },
                { text: 'Recibido', value: 'producto.pivot.cantidad_recibido' },
                { text: 'Tipo', value: 'motivo.estado' },
                { text: 'Motivo', value: 'motivo.nombre' },
                { text: 'Comentarios', value: 'producto.pivot.observacion' },
                ]" :items='<?php echo json_encode($observados, 15, 512) ?>'></index-component>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/requerimiento/rechazo/show.blade.php ENDPATH**/ ?>