<?php $__env->startSection('title', 'Crear Punto de Abastecimiento | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Nueva Empresa</h3>
            <div class="card-body">
                <form action="<?php echo e(route('abastecimientos.store')); ?>" method="POST" accept-charset="utf-8">
                    <?php echo csrf_field(); ?>

                    <div class="form-group row">
                        <label class="col-sm-2" for="nombre">Nombre:</label>
                        <span class="col-sm-6">
                            <input class="form-control" required type="text" name="nombre">
                            <p class="text-muted">Obligatorio</p>
                        </span>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2" for="comuna">Comuna:</label>
                        <span class="col-sm-6">
                            <input class="form-control" required type="text" name="comuna">
                            <p class="text-muted">Obligatorio</p>
                        </span>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2" for="ciudad">Ciudad:</label>
                        <span class="col-sm-6">
                            <input class="form-control" required type="text" name="ciudad">
                            <p class="text-muted">Obligatorio</p>
                        </span>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">Guardar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mline-siger/resources/views/abastecimiento/create.blade.php ENDPATH**/ ?>