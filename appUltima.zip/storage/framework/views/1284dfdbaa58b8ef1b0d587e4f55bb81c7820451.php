<?php $__env->startSection('title', 'Orden de Compra | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
<?php $__env->startSection('home-route', route('compass.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="card">
        <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Control de Ordenes de Compra</h3>
        <div class="card-body">
            <div class="container mt-2">
                <form class="flex flex-row items-end" method="POST" action="<?php echo e(route("orden_compra_filtrar")); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($empresas) && count($empresas) > 0): ?>
                    <div class="flex flex-col">
                        <label for="">Empresa:</label>
                        <select class="form-control" name="empresa_id" required>
                            <option>Seleccione una empresa</option>
                            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($empresa->id); ?>"><?php echo e($empresa->razon_social); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    <div class="flex flex-col mx-2">
                        <label for="">Desde:</label>
                        <input type="date" name="inicio" class="form-control" required />
                    </div>

                    <div class="flex flex-col">
                        <label for="">Hasta:</label>
                        <input type="date" name="fin" class="form-control" required />
                    </div>
                    <div class="flex flex-col mx-2">
                        <button type="submit" class="btn btn-primary">Mostrar estados de pagos en este periodo</button>
                    </div>
                </form>
                <?php if(isset($cierres)): ?>
                <table class="table table-sm" id="datatable">
                    <thead>
                        <tr>
                            <th>Folio EDP</th>
                            <th>Periodo</th>
                            <th>Monto</th>
                            <th>Accion</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cierres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cierre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(date_format($cierre->created_at, "d/m/Y")); ?>-<?php echo e($cierre->id); ?></td>
                            <td><?php echo e($cierre->desde); ?> -> <?php echo e($cierre->hasta); ?></td>
                            <td>$ <?php echo e(number_format($cierre->monto, 0)); ?></td>
                            <td>
                                <a href="<?php echo e(route('orden_compra_cierre', $cierre)); ?>">Seleccionar</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/alogis_dev/resources/views/orden_compra/index.blade.php ENDPATH**/ ?>