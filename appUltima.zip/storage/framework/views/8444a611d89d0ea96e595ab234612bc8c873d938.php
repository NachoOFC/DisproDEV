<?php $__env->startSection('title', 'Cuenta Corriente | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Cuenta Corriente</h3>
            <div class="card-body">
                <div class="container">
                    <div class="row">
                        <form action="<?php echo e(route("presupuesto.indexEmpresa")); ?>" class="form-group form-row">
                            <label class="col-md-2 col-form-label text-md-right">Mes:</label>
                            <div class="col-md-4">
                                <select class="form-control form-control-sm" name="mes">
                                    <?php for($i = 1; $i < 13; $i++): ?>
                                        <option value="<?php echo e($i); ?>"><?php echo e(DateTime::createFromFormat('!m', $i)->format('F')); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <label class="col-md-2 col-form-label text-md-right">Año:</label>
                            <div class="col-md-3">
                                <select class="form-control form-control-sm" name="year">
                                    <?php for($i = date("Y"); $i < date("Y") + 6; $i++): ?>
                                        <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-1"><button class="btn btn-primary">Filtrar</button></div>
                        </form>
                    </div>
                </div>
                <ul class="nav">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route("presupuesto.indexEmpresa", ['acumulado' => true])); ?>">Acumulado</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route("presupuesto.indexEmpresa", ['acumulado' => false])); ?>">Solo Mes</a></li>
                </ul>
                <div class="container mt-2">
                    <div class="table-responsive">
                        <table id="datatable-presupuesto" class="table table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th scope="col" class="text-center">Fecha</th>
                                    <th scope="col" class="text-center">Concepto</th>
                                    <th scope="col" class="text-center">Tipo</th>
                                    <th scope="col" class="text-center">Id</th>
                                    <th scope="col" class="text-center">Entrada ($)</th>
                                    <th scope="col" class="text-center">Salida ($)</th>
                                    <th scope="col" class="text-center">Saldo ($)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($date); ?></td>
                                    <td>Presupuesto</td>
                                    <td>Carga Inicial</td>
                                    <td class="text-center"><?php echo e(__($date->year.$date->month)); ?></td>
                                    <td class="text-right"><?php echo e(number_format($inicial, 0)); ?></td>
                                    <td></td>
                                    <td class="text-right"><?php echo e(number_format($inicial, 0)); ?></td>
                                </tr>
                                <?php
                                    $saldo = ($inicial / 100);
                                ?>
                                <?php $__currentLoopData = $requerimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $requerimiento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($pedido->created_at); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('presupuesto.indexCentro', ['centroId' => $pedido->centro()->get()->first()->id])); ?>">
                                                    <?php echo e($pedido->nombre); ?>

                                                </a>
                                            </td>
                                            <td>Orden de Pedido</td>
                                            <td class="text-center">
                                                <modal-btn-component
                                                    :button="false"
                                                    title="Orden de Pedido"
                                                    :message='[
                                                    { data: <?php echo json_encode($pedido->centro, 15, 512) ?>, type: "Object", keys: ["nombre"]},
                                                    { data: <?php echo json_encode($pedido->productos, 15, 512) ?>, type: "Array", keys: ["sku",
                                                    "detalle", "precio",
                                                    "pivot", "total"], pivot: "cantidad"},
                                                    { data: <?php echo json_encode(["total" => "$" . number_format($pedido->getTotal()) ], 15, 512) ?>, type: "Object", keys: ["total"]}
                                                    ]'><?php echo e($pedido->id); ?></modal-btn-component>
                                            </td>
                                            <td></td>
                                            <td class="text-right"><?php echo e(number_format($pedido->getTotal(), 0)); ?></td>
                                            <td class="text-right"><?php echo e(number_format(($saldo -= $pedido->getTotal()), 0)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jmonagas/Projects/mline-siger/resources/views/presupuesto/index/empresa.blade.php ENDPATH**/ ?>