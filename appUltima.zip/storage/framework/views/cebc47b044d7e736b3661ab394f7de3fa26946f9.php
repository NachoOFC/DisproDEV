<?php echo e($slot); ?>

<?php /**PATH /home/mlinecl/alogis_dev/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>