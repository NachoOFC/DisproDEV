<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Alogis</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@mdi/font@5.x/css/materialdesignicons.min.css" rel="stylesheet">

    <!-- Style -->
    <link href="<?php echo e(asset(mix('css/app.css'))); ?>" rel="stylesheet">

</head>

<body class="bg-grey-lightest font-sans leading-normal tracking-normal">
    <div id="app">
        <v-app>
            <header class="navbar navbar-dark bg-gray-200 flex-md-nowrap px-4 py-1 shadow z-10 fixed top-0 left-0 right-0">
                <?php if(auth()->guard()->check()): ?>
                <button class="btn btn-outline-dark" type="button" data-toggle="collapse" data-target="#sidenav" aria-expanded="true" aria-controls="sidenav" id="sidenavBtn" hidden>
                    <i class="fas fa-bars"></i>
                </button>
                <?php endif; ?>
                <a class="navbar-brand" href="<?php echo $__env->yieldContent('home-route'); ?>">
                    <div class="d-flex flex-row align-items-baseline justify-content-center h3">
                        <img src="<?php echo e(asset('img/LogoAlogis.jpeg')); ?>" class="w-40 h-20 img-fluid" alt="" />
                        <span class="h1 text-primary font-bold italic ml-2 mb-1 p-2">Alogis</span>
                    </div>
                </a>

                <?php if(auth()->guard()->check()): ?>
                <ul class="nav ml-auto text-light">

                    <li class="nav-item">
                        <a href="<?php echo e(route('notifications')); ?>" class="nav-link">
                            <i class="fas fa-bell"></i>
                            <span class="badge badge-danger"><?php echo e(count(Auth::user()->unreadNotifications)); ?></span>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a id="user-dropdown" href="" class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                            Hola, <?php echo e(Auth::user()->name); ?>

                        </a>
                        <div class="dropdown-menu" aria-labelledby="user-dropdown">
                            <form action="<?php echo e(route('logout')); ?>" method="POST" accept-charset="utf-8">
                                <?php echo csrf_field(); ?>

                                <button class="dropdown-item" type="submit">Salir</button>
                            </form>
                        </div>
                    </li>
                </ul>
                <?php endif; ?>
            </header>

            <div class="container-fluid mt-40">
                <div class="row">
                    <div id="sidenav" class="col-md-2 collapse show ">
                        <nav class="d-none d-md-block bg-light sidebar pt-8 ">
                            <div class="nav flex-column mt-4">
                                <?php if (! empty(trim($__env->yieldContent('nav-menu')))): ?>
                                <?php echo $__env->yieldContent('nav-menu'); ?>
                                <?php endif; ?>
                            </div>
                        </nav>
                    </div>

                    <main class="col pt-4 w-96">
                        <?php if (! empty(trim($__env->yieldContent('main')))): ?>
                        <?php echo $__env->yieldContent('main'); ?>
                        <?php endif; ?>
                        <?php if (! empty(trim($__env->yieldContent('content')))): ?>
                        <?php echo $__env->yieldContent('content'); ?>
                        <?php endif; ?>
                    </main>
                </div>
            </div>

    </div>

    <!-- Footer -->
    <footer class="row border-top bg-light mt-5 p-5 align-items-center justify-content-center">
        <a href="https://www.mline.cl/web/" target="_blank" class="d-flex flex-row align-items-center">
            <img alt="Logo de Mline SPA" src="<?php echo e(asset('img/logo-mline.png')); ?>" class="w-32 img-fluid" />
            <i class="fas fa-copyright"></i>
            Todos los derechos reservados. <?php echo e(date("Y")); ?>

        </a>
    </footer>
    <!-- /Footer -->

    <!-- Scripts -->
    <script src="<?php echo e(asset(mix('js/app.js'))); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js" charset="utf-8"></script>
    <?php echo $__env->yieldContent('js'); ?>

    <?php if(\Session::has('msg')): ?>
    <?php
    $msg = \Session::get('msg');
    ?>
    <script charset="utf-8">
        (Swal.fire({
            title: '<?php echo e(isset($msg["meta"]["title"]) ? $msg["meta"]["title"] : "Accion Realizada"); ?>',
            html: '<?php echo isset($msg["meta"]["msg"]) ? $msg["meta"]["msg"] : "Todo listo"; ?>'
        }))();
    </script>
    <?php endif; ?>
    </v-app>
</body>

</html><?php /**PATH /home/mlinecl/alogis_dev/resources/views/layouts/app.blade.php ENDPATH**/ ?>