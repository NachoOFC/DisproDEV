<?php $__env->startSection('title', 'Crear Centro | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\Empresa)): ?>
    <?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php elseif(Auth::user()->userable instanceof \App\CompassRole): ?>
    <?php $__env->startSection('home-route', route('compass.home')); ?>
<?php endif; ?>

<?php $__env->startSection('nav-menu'); ?>
<?php if((Auth::user()->userable instanceof \App\Empresa)): ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(Auth::user()->userable instanceof \App\CompassRole): ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl">Nuevo Centro</h3>
            <div class="card-body">
                <form action="<?php echo e(route('centros.store')); ?>" method="POST" accept-charset="utf-8">
                    <?php echo csrf_field(); ?>

                    <div class="form-group row">
                        <label class="col-sm-2" for="razon_social">Nombre:</label>
                        <span class="col-sm-6">
                            <input class="form-control" required type="text" name="nombre">
                            <p class="text-muted">Obligatorio</p>
                        </span>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2" for="direccion">Direccion:</label>
                        <span class="col-sm-6">
                            <input class="form-control" required type="text" name="direccion">
                            <p class="text-muted">Obligatorio</p>
                        </span>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2" for="comuna">Comuna:</label>
                        <span class="col-sm-6">
                            <input class="form-control" required type="text" name="comuna">
                            <p class="text-muted">Obligatorio</p>
                        </span>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2" for="ciudad">Ciudad:</label>
                        <span class="col-sm-6">
                            <input class="form-control" required type="text" name="ciudad">
                            <p class="text-muted">Obligatorio</p>
                        </span>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2" for="holding">Empresa Dueña:</label>
                        <span class="col-sm-6">
                            <select name="empresa" class="form-control">
                                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($empresa->id); ?>"><?php echo e($empresa->razon_social); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </span>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">Guardar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mline-siger/resources/views/centro/create.blade.php ENDPATH**/ ?>