<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

    <?php $__env->startSection('nav-menu'); ?>
        <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('main'); ?>
        <div class="container">
            <div class="card">
                <div class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Servicio al Cliente</div>
                <div class="card-body">
                    <form
                        method="POST"
                        action="<?php echo e(route("servicio-cliente.submit")); ?>"
                        enctype="multipart/form-data"
                    >
                        <?php echo csrf_field(); ?>

                        <div class="form-group form-row">
                            <div class="col-md-2">
                                <label for="minuta">Minuta:</label>
                            </div>
                            <div class="col-md-6">
                                <input class="form-control" type="file" name="minuta" />
                                <?php if(isset($status)): ?>
                                    <?php if($status["minuta"]): ?>
                                        <div class="alert alert-success">
                                            Cargado exitosamente
                                        </div>
                                    <?php else: ?>
                                        <div class="alert alet-danger">
                                            No se pudo cargar, intente nuevamente en unos minutos.
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group form-row">
                            <div class="col-md-2">
                                <label for="saludable">Consejos Vida Saludable:</label>
                            </div>
                            <div class="col-md-6">
                                <input class="form-control" type="file" name="saludable" />
                                <?php if(isset($status)): ?>
                                    <?php if($status["saludable"]): ?>
                                        <div class="alert alert-success">
                                            Cargado exitosamente
                                        </div>
                                    <?php else: ?>
                                        <div class="alert alet-danger">
                                            No se pudo cargar, intente nuevamente en unos minutos.
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        <button class="btn btn-primary">Cargar</button>
                    </form>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/compass/servicio-cliente.blade.php ENDPATH**/ ?>