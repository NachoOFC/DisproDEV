<?php $__env->startSection('title', 'Nota de Credito | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
<?php $__env->startSection('home-route', route('compass.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="card">
        <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: <?php if(isset($notaCreditoTributaria)): ?> Editar <?php else: ?> Crear <?php endif; ?> Nota de Credito <?php if(isset($notaCreditoTributaria)): ?> <?php echo e($notaCreditoTributaria->folio); ?> <?php endif; ?></h3>
        <div class="card-body">
            <div class="container mt-2">
                <?php if(null !== session()->get("error")): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get("error")); ?>

                </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e($route); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="d-flex justify-content-around">
                        <div class="d-inline-flex flex-column form-group">
                            <label for="">Fecha:</label>
                            <input required class="form-control" name="fecha" type="date" <?php if(isset($notaCreditoTributaria)): ?> value="<?php echo e($notaCreditoTributaria->fecha); ?>" <?php elseif(null !==(old('fecha'))): ?> value=<?php echo e(old('fecha')); ?> <?php endif; ?> />
                        </div>
                        <div class="d-inline-flex flex-column form-group">
                            <label for="">Folio:</label>
                            <input required class="form-control" name="folio" type="text" <?php if(isset($notaCreditoTributaria)): ?> value="<?php echo e($notaCreditoTributaria->folio); ?>" <?php elseif(null !==(old('folio'))): ?> value=<?php echo e(old('folio')); ?> <?php endif; ?> />
                        </div>
                        <div class="d-inline-flex flex-column form-group">
                            <label for="">Monto:</label>
                            <input required class="form-control" name="monto" type="text" <?php if(isset($notaCreditoTributaria)): ?> value="<?php echo e($notaCreditoTributaria->monto); ?>" <?php elseif(null !==(old('monto'))): ?> value=<?php echo e(old('monto')); ?> <?php endif; ?> />
                        </div>
                        <div class="d-inline-flex flex-column form-group">
                            <label for="">Documento:</label>
                            <input class="form-control" name="documento" type="file" value="" />
                        </div>

                        <button type="submit" class="btn btn-success">Guardar</button>
                    </div>

                    <div class="container">
                        <div class="row">
                            <div class="col-md-4">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Centro</th>
                                            <th>Monto</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($centro["nombre"]); ?></th>
                                            <td>
                                                <input class="form-control" type="text" name="centro-<?php echo e($centro["id"]); ?>" <?php if(isset($centro["pivot"])): ?> value="<?php echo e($centro["pivot"]["monto"]); ?>" <?php elseif(null !==(old('monto'))): ?> value=<?php echo e(old("centro-".$centro["id"])); ?> <?php endif; ?> />
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/nota_credito/create-edit.blade.php ENDPATH**/ ?>