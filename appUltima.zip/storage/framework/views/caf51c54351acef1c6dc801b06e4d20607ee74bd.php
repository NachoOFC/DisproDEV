<?php if($type === 0): ?>
<!-- Tipo Centro -->
<table id="datatable" class="table">
    <thead>
        <tr>
            <th scope="col">Nombre</th>
            <th scope="col">Folios</th>
            <th scope="col">Estado</th>
            <?php if((Auth::user()->userable instanceof \App\Centro)): ?>
            <th scope="col">Libreria</th>
            <?php endif; ?>
            <th scope="col">Creado</th>
            <th scope="col">Actualizado</th>
            <th scope="col">Accion</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $requerimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <a href="<?php echo e(route('pedidos.show', $requerimiento)); ?>">
                    <?php echo e($requerimiento->nombre); ?>

                </a>
            </td>
            <td>
                <?php echo e($requerimiento->folio ? $requerimiento->folio->join(", ") : "N/A"); ?>

            </td>
            <td><?php echo e($requerimiento->estado); ?></td>
            <?php if((Auth::user()->userable instanceof \App\Centro)): ?>
            <td>
                <agregar-libreria-component action="<?php echo e(route('libreria.editar', $requerimiento)); ?>" :library='<?php echo json_encode(Auth::user()
                                        ->hasRequerimiento($requerimiento), 15, 512) ?>'></agregar-libreria-component>
            </td>
            <?php endif; ?>
            <td><?php echo e(date_format($requerimiento->created_at, "d-m-Y")); ?></td>
            <td><?php echo e(date_format($requerimiento->updated_at, "d-m-Y")); ?></td>
            <td>
                <div class="btn-group" role="group">
                    <?php if(Auth::user()->userable instanceof \App\Centro): ?>
                    <?php if( $requerimiento->estado === 'DESPACHADO'): ?>
                    <a class="btn btn-outline-success" href="<?php echo e(route(
                                                 'pedidos.recepcion',
                                                 $requerimiento)); ?>">
                        Recepcion de Pedido
                    </a>
                    <?php endif; ?>
                    <?php if( $requerimiento->estado === 'RECIBIDO CON OBSERVACIONES'): ?>
                    <a class="btn btn-outline-info" href="<?php echo e(route(
                                                 'rechazos.show',
                                                 $requerimiento)); ?>">
                        Ver Observaciones
                    </a>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if( $requerimiento->estado === 'DESPACHADO'): ?>
                    <modal-btn-component title="Orden de Pedido" :message='[
                                           { data: <?php echo json_encode([
                                               "nombre" => $requerimiento->transporte->nombre_chofer, "rut" => $requerimiento->transporte->rut_chofer, "contacto" => $requerimiento->transporte->contacto
                                           ]) ?>
                                           , type: "Object", keys: ["nombre",
                                           "rut", "contacto"]}
                                           ]'>
                        Ver Transporte
                    </modal-btn-component>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php elseif($type === 1): ?>
<!-- Tipo Empresa -->
<div class="table-responsive">
    <table id="datatable" class="table table-sm">
        <thead>
            <tr>
                <th scope="col" rowspan="2">Nombre</th>
                <th scope="col" rowspan="2">Accion</th>
                <th class="text-center" scope="row" colspan="<?php echo e(\App\Estado::all()->count()); ?>">Estados</th>
            </tr>
            <tr>
                <?php $__currentLoopData = \App\Estado::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th scope="col"><?php echo e($estado->nombre); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php if(Auth::user()->userable instanceof \App\Empresa): ?>
                <!-- Si el usuario es de tipo Empresa -->
                <?php
                    $empresa = Auth::user()->userable; // Obtener la empresa del usuario
                    $centrosAsignados = Auth::user()->centros; // Centros asignados al usuario
                    $centros = $centrosAsignados->count() > 0 ? $centrosAsignados : $empresa->centros; // Mostrar centros asignados o todos los centros de la empresa
                ?>

                <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($centro->nombre); ?></td>
                        <td>
                            <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '0'])); ?>">
                                Ver Detalles
                            </a>
                        </td>
                        <?php $__currentLoopData = \App\Estado::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>
                            <?php echo e(count($centro->requerimientos()->where('estado', $estado->nombre)->get())); ?>

                        </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <!-- Si no es de tipo Empresa, mantener la lógica actual -->
                <?php if(Auth::user()->centro): ?>
                    <!-- Si el usuario tiene un centro asignado, mostrar solo los requerimientos de ese centro -->
                    <?php
                        $centro = Auth::user()->centro;
                        $requerimientos = $centro->requerimientos()->where("created_at", ">=", now()->subMonths(3))->get();
                    ?>
                    <tr>
                        <td><?php echo e($centro->nombre); ?></td>
                        <td>
                            <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '0'])); ?>">
                                Ver Detalles
                            </a>
                        </td>
                        <?php $__currentLoopData = \App\Estado::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>
                            <?php echo e(count($requerimientos->where('estado', $estado->nombre))); ?>

                        </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php else: ?>
                    <!-- Si no tiene un centro asignado, mostrar todos los centros -->
                    <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($centro->nombre); ?></td>
                        <td>
                            <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '0'])); ?>">
                                Ver Detalles
                            </a>
                        </td>
                        <?php $__currentLoopData = \App\Estado::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>
                            <?php echo e(count($centro->requerimientos()->where('estado', $estado->nombre)->get())); ?>

                        </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php elseif($type === 2): ?>
<!-- Tipo Holding -->
<div class="table-responsive">
    <table id="datatable" class="table table-sm">
        <thead class="" style='color: #B5B2B2; background-color:#383636'>
            <tr>
                <th scope="col" rowspan="2" class="border-solid border border-white " ><div class="text-center">Nombre</div></th>
                <th scope="col" rowspan="2" class="border-solid border border-white text-center">Accion</th>
                <th class="text-center border-solid border border-white text-center" scope="row"  colspan="<?php echo e(\App\Estado::all()->count()); ?>">Estados</th>
            </tr>
            <tr>
                <?php $__currentLoopData = \App\Estado::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th scope="col" class="border-solid border border-white text-center"><?php echo e($estado->nombre); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($empresa->razon_social); ?></td>
                <td>
                    <a href="<?php echo e(route('pedidos.indexCentro', ['empresa' => $empresa, 'estado' => 0])); ?>">
                        Ver Todos
                    </a>
                </td>
                <?php $__currentLoopData = \App\Estado::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td>
                    <a href="<?php echo e(route('pedidos.indexCentro', ['empresa' => $empresa, 'estado' => $estado->id])); ?>">
                        <?php echo e(count($empresa->getRequerimientoByEstado($estado->nombre))); ?>

                    </a>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php endif; ?><?php /**PATH /home/mlinecl/alogis_dev/resources/views/partials/index.blade.php ENDPATH**/ ?>