<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
    <a class="btn btn-secondary" style="color: #fff;"  href="<?php echo e(route('compass.home')); ?>">Pagina anterior</a>
        <div class="card">
            <div class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Despachar</div>
            <div class="card-body table-responsive">
                <table class="table table-sm" id="datatable">
                    <thead>
                        <tr>
                            <th scope="col">Folio</th>
                            <th scope="col">Nombre Transportista</th>
                            <th scope="col">Contacto Transportista</th>
                            <th scope="col">Cajas</th>
                            <th scope="col">Fecha Programada</th>
                            <th scope="col">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $despachos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $despacho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($despacho->id); ?></th>
                                <td><?php echo e($despacho->nombre_chofer); ?></td>
                                <td><?php echo e($despacho->contacto); ?></td>
                                <td>
                                    <modal-btn-component
                                        title="Despacho Programado"
                                        :message='[
                                        { data: <?php echo json_encode($despacho->requerimientos, 15, 512) ?>
                                        , type: "Array", keys: ["id", "nombre",
                                        "created_at"]}
                                        ]'>Ver Pedidos</modal-btn-component>
                                </td>
                                <td><?php echo e($despacho->fecha_programada); ?></td>
                                <td>
                                    <despachar-component
                                        action-guia="<?php echo e(route('guia-despacho.create', $despacho->id)); ?>"
                                        action-despachar="<?php echo e(route('compass.despachar', $despacho)); ?>"
                                        action-eliminar="<?php echo e(route('compass.eliminarDespacho',
                                        $despacho)); ?>"
                                        ></despachar-component>
                                        <a class="btn btn-info" href="<?php echo e(route('guia-despacho.index', $despacho)); ?>">Ver guias de despacho</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/compass/despachar.blade.php ENDPATH**/ ?>