

<?php $__env->startSection('title', 'Cuenta Corriente | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="card">
        <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Cuenta Corriente</h3>
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <form action="<?php echo e(route('presupuesto.indexEmpresa')); ?>" method="GET" class="form-row align-items-center">
                        <!-- Mes -->
                        <div class="form-group col-md-3">
                            <label for="month">Mes:</label>
                            <select class="form-control form-control-sm" name="month" id="month">
                                <?php for($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e(request('month') == $i ? 'selected' : ''); ?>>
                                        <?php echo e(DateTime::createFromFormat('!m', $i)->format('F')); ?>

                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>

                        <!-- Año -->
                        <div class="form-group col-md-2">
                            <label for="year">Año:</label>
                            <select class="form-control form-control-sm" name="year" id="year">
                                <?php for($i = date("Y") - 5; $i < date("Y") + 10; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e(request('year') == $i ? 'selected' : ''); ?>>
                                        <?php echo e($i); ?>

                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>

                        <!-- Centro -->
                        <div class="form-group col-md-3">
                            <label for="centro_id">Centro:</label>
                            <select class="form-control" name="centro_id" id="centro_id">
                                <option value="">Todos</option>
                                <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($centro->id); ?>" <?php echo e(request('centro_id') == $centro->id ? 'selected' : ''); ?>>
                                        <?php echo e($centro->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Acumulado -->
                        <div class="form-group col-md-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="acumulado" id="acumulado" value="1" <?php echo e(request('acumulado') ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="acumulado">Acumulado</label>
                            </div>
                        </div>

                        <!-- Bot���n de env���o -->
                        <div class="col-md-1">
                            <button type="submit" class="btn btn-primary">Filtrar</button>
                        </div>
                    </form>
                </div>
            </div>

            <?php if(isset($requerimientos)): ?>
            <div class="container mt-2">
                <div class="table-responsive">
                    <table id="datatable-presupuesto" class="table table-bordered table-sm">
                        <thead>
                            <tr>
                                <th scope="col" class="text-center">Fecha</th>
                                <th scope="col" class="text-center">Concepto</th>
                                <th scope="col" class="text-center">Tipo</th>
                                <th scope="col" class="text-center">Id</th>
                                <th scope="col" class="text-center">Entrada ($)</th>
                                <th scope="col" class="text-center">Salida ($)</th>
                                <th scope="col" class="text-center">Saldo ($)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($date); ?></td>
                                <td>Presupuesto</td>
                                <td>Carga Inicial</td>
                                <td class="text-center"><?php echo e(__($date->year.$date->month)); ?></td>
                                <td class="text-right"><?php echo e(number_format($inicial, 0)); ?></td>
                                <td></td>
                                <td class="text-right"><?php echo e(number_format($inicial, 0)); ?></td>
                            </tr>
                            <?php
                            $saldo = ($inicial / 100);
                            ?>
                            <?php $__currentLoopData = $requerimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $requerimiento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pedido->created_at); ?></td>
                                <td>
                                    <a href="<?php echo e(route('presupuesto.indexCentro', ['centroId' => $pedido->centro()->get()->first()->id])); ?>">
                                        <?php echo e($pedido->nombre); ?>

                                    </a>
                                </td>
                                <td>Orden de Pedido</td>
                                <td class="text-center">
                                    <modal-btn-component :button="false" title="Orden de Pedido" :message='[
                                                    { data: <?php echo json_encode($pedido->centro, 15, 512) ?>, type: "Object", keys: ["nombre"]},
                                                    { data: <?php echo json_encode($pedido->productos, 15, 512) ?>, type: "Array", keys: ["sku",
                                                    "detalle", "precio",
                                                    "pivot", "total"], pivot: "cantidad"},
                                                    { data: <?php echo json_encode(["total" => "$" . number_format($pedido->getTotal()) ], 15, 512) ?>, type: "Object", keys: ["total"]}
                                                    ]'><?php echo e($pedido->id); ?></modal-btn-component>
                                </td>
                                <td></td>
                                <td class="text-right"><?php echo e(number_format($pedido->getTotal(), 0)); ?></td>
                                <td class="text-right"><?php echo e(number_format(($saldo -= $pedido->getTotal()), 0)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/alogis_dev/resources/views/presupuesto/index/empresa.blade.php ENDPATH**/ ?>