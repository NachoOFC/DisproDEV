<?php $__env->startSection('title', 'Crear Orden de Pedido | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="card">
        <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->userable->nombre); ?>: Nueva Orden de Pedido</h3>
        <div class="card-body">
          <?php if(isset($err)): ?>
            <div class="row">
              <div class="col-md-6 mx-auto">
                <div class="alert alert-danger">
                  Ocurrior un error en las siguientes columnas:
                  <ul>
                    <?php $__currentLoopData = $err; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li>
                        <?php echo e($error); ?>

                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <div class="row justify-content-center align-items-center">
            <div class="col-md-6">
              <a class="btn btn-info" href="<?php echo e(route('requerimientos.formato')); ?>">Descargar Formato</a>
            </div>
            <div class="col-md-6">
              <form method="POST" action="<?php echo e(route('requerimientos.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-row">
                  <label for="">Ingresa el formato:</label>
                  <input name="productos" class="form-control" type="file" value=""/>
                </div>

                <button class="btn btn-info mt-4">Cargar</button>

              </form>
            </div>

          </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jmonagas/Projects/mline-siger/resources/views/requerimiento/create.blade.php ENDPATH**/ ?>