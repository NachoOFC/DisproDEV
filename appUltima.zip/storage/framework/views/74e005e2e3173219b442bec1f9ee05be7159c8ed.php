

<?php $__env->startSection('title', 'Editar Presupuesto | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl">Editar Presupuesto - <?php echo e($centro->nombre); ?> (<?php echo e($year); ?>)</h3>
            <div class="card-body">
                <form action="<?php echo e(route('presupuesto.actualizar', [$centro->id, $year])); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Mes</th>
                                <th>Monto</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $montosPorMes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes => $monto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(DateTime::createFromFormat('!m', $mes)->format('F')); ?></td>
                                    <td>
                                        <input type="number" name="montos[<?php echo e($mes); ?>]" value="<?php echo e($monto); ?>" class="form-control" min="0" step="0.01" required>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="text-center mt-4">
                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/alogis_dev/resources/views/presupuesto/editar.blade.php ENDPATH**/ ?>