<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Asignacion Masiva de
            Productos - Empresa - Precio</div>
            <div class="card-body">
                <ol>
                    <li>1. Descarga el formato de Excel: 
                        <a class="dropdown-item" href="<?php echo e(route('productos.asignacionMasivaFormato')); ?>" target="_blank">Aqui</a>
                    </li>
                    <li>2. Ingresa los datos en el archivo:
                        <ul class="list-group">
                            <li class="list-group-item">
                                Coloca los valores requeridos:
                                <table class="table table-bordered table-sm">
                                    <tr>
                                        <th scope="row">SKU</th>
                                        <td>
                                            <p class="text-danger">NO MODIFICAR.</p>
                                            Valor de referencia del sistema para identificar producto.
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Detalle</th>
                                        <td>
                                            <p class="text-info">Identificacion. No necesita ingreso de datos.</p>
                                            Nombre del producto.
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Precio Costo</th>
                                        <td>
                                            <p class="text-danger">NO MODIFICAR.</p>
                                            Costo de ese producto.
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Porcentaje Ganancia</th>
                                        <td>
                                            <p class="text-success">INGRESAR DATO.</p>
                                            El margen de ganancia en porcentaje para ese producto
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Neto</th>
                                        <td>
                                            <p class="text-info">Calculo. No necesita ingreso de datos.</p> 
                                            Valor calculado entre el precio de costo y el porcentaje de ganancia.
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Precio Venta</th>
                                        <td>
                                            <p class="text-primary">Calculo. 
                                                <b>Si se ingresa un valor de 0 o un campo vacio entonces el producto no estara disponible para la empresa asociada.</b>
                                            </p>
                                            Valor calculado entre el neto y el IVA.
                                        </td>
                                    </tr>
                                </table>
                            </li>
                            <li class="list-group-item">
                                <p class="text-danger">
                                    Un valor de precio venta igual a 0 o vacio quiere decir que ese producto no estara
                                    disponible para la empresa asociada, por lo tanto este
                                    producto no saldra como opcion a los centros de esa empresa  al momento de
                                    crear ordenes de pedidos.
                                </p>
                            </li>
                        </ul>
                    </li>
                    <li>3. Sube el archivo modificado aqui:
                        <form action="<?php echo e(route('productos.asignacionMasiva')); ?>" method="POST"  enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-row align-items-end mt-4">
                                <div class="form-group col-md">
                                    <label for="empresa">Seleccione la empresa:</label>
                                    <select name="empresa" class="form-control">
                                        <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($empresa->id); ?>"><?php echo e($empresa->razon_social); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-md">
                                    <label for="formato">Ingrese el archivo modificado:</label>
                                    <input type="file" class="form-control-file" name="formato">
                                </div>
                                <div class="form-group col-md">
                                    <label for="fecha">Ingrese la Fecha cuando se aplicaran los cambios:</label>
                                    <input type="date" class="form-control" name="fecha">
                                </div>
                            </div>
                            <div class="col-md">
                                <button class="btn btn-primary" type="submit">Guardar</button>
                            </div>
                        </form>
                    </li>
                </ol>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mline-siger/resources/views/compass/producto/asignacion_masiva.blade.php ENDPATH**/ ?>