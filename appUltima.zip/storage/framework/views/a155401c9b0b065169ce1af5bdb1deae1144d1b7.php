<?php echo e($slot); ?>

<?php /**PATH /home/mlinecl/siger_prod/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>