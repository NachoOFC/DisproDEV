<?php $__env->startSection('title', 'Lista de Ordenes | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
    <?php $__env->startSection('home-route', route('compass.home')); ?>
    <?php $__env->startSection('nav-menu'); ?>
        <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php else: ?>
    <?php $__env->startSection('home-route', route('cliente.home')); ?>
    <?php $__env->startSection('nav-menu'); ?>
        <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
    
        <div class="card">
            <h3 class="card-header font-bold text-xl">Lista de Orden de Pedidos</h3>
            <div class="card-body">
                <h5 class="card-title h4 text-center border-bottom"><?php echo e($centro->nombre); ?></h5>
                <table class="table table-sm table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Control</th>
                            <?php for($i = 1; $i < 13; $i++): ?>
                                <th scope="col">
                                    <?php echo e(ucfirst(\Carbon\Carbon::parse( date("Y-") . $i . date("-d") )->locale('es')->monthName)); ?>

                                </th>
                            <?php endfor; ?>
                            <th scope="col">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row">N° de Pedidos</th>
                            <?php for($i = 0; $i < 13; $i++): ?>
                                <td>
                                    <?php echo e($counts[$i]); ?>

                                </td>
                            <?php endfor; ?>
                        </tr>
                        <tr>
                            <th scope="row">N° de Productos</th>
                            <?php for($i = 0; $i < 13; $i++): ?>
                                <td>
                                    <?php echo e($products[$i]); ?>

                                </td>
                            <?php endfor; ?>
                        </tr>
                        <tr>
                            <th scope="row">Costo Total ($)</th>
                            <?php for($i = 0; $i < 13; $i++): ?>
                                <td>
                                    <?php echo e(number_format($totals[$i], 0)); ?>

                                </td>
                            <?php endfor; ?>
                        </tr>
                        <tr>
                            <th scope="row">Esperando validacion</th>
                            <?php
                                $total = 0;
                            ?>
                            <?php for($i = 1; $i < 13; $i++): ?>
                                <?php if($estados->has(str_pad($i, 2, "0", STR_PAD_LEFT)) && $estados[str_pad($i, 2, "0", STR_PAD_LEFT)]->has('ESPERANDO VALIDACION')): ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '0'])); ?>">
                                            <?php echo e($total += count($estados[str_pad($i, 2, "0", STR_PAD_LEFT)]['ESPERANDO VALIDACION'])); ?>

                                        </a>
                                    </td>
                                <?php else: ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '0'])); ?>">
                                            0
                                        </a>
                                    </td>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <td> <?php echo e($total); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Validado</th>
                            <?php
                                $total = 0;
                            ?>
                            <?php for($i = 1; $i < 13; $i++): ?>
                                <?php if($estados->has(str_pad($i, 2, "0", STR_PAD_LEFT)) && $estados[str_pad($i, 2, "0", STR_PAD_LEFT)]->has('VALIDADO')): ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '1'])); ?>">
                                            <?php echo e($total += count($estados[str_pad($i, 2, "0", STR_PAD_LEFT)]['VALIDADO'])); ?>

                                        </a>
                                    </td>
                                <?php else: ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '1'])); ?>">
                                            0
                                        </a>
                                    </td>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <td> <?php echo e($total); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">En Procesamiento</th>
                            <?php for($i = 1; $i < 13; $i++): ?>
                                <?php if($estados->has(str_pad($i, 2, "0", STR_PAD_LEFT)) && $estados[str_pad($i, 2, "0", STR_PAD_LEFT)]->has('EN PROCESAMIENTO')): ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '2'])); ?>">
                                            <?php echo e($total += count($estados[str_pad($i, 2, "0", STR_PAD_LEFT)]['EN PROCESAMIENTO'])); ?>

                                        </a>
                                    </td>
                                <?php else: ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '2'])); ?>">
                                            0
                                        </a>
                                    </td>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <td><?php echo e($total); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">En Bodega</th>
                            <?php
                                $total = 0;
                            ?>
                            <?php for($i = 1; $i < 13; $i++): ?>
                                <?php if($estados->has(str_pad($i, 2, "0", STR_PAD_LEFT)) && $estados[str_pad($i, 2, "0", STR_PAD_LEFT)]->has('EN BODEGA')): ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '3'])); ?>">
                                            <?php echo e($total += count($estados[str_pad($i, 2, "0", STR_PAD_LEFT)]['EN BODEGA'])); ?>

                                        </a>
                                    </td>
                                <?php else: ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '3'])); ?>">
                                            0
                                        </a>
                                    </td>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <td><?php echo e($total); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Despachado</th>
                            <?php
                                $total = 0;
                            ?>
                            <?php for($i = 1; $i < 13; $i++): ?>
                                <?php if($estados->has(str_pad($i, 2, "0", STR_PAD_LEFT)) && $estados[str_pad($i, 2, "0", STR_PAD_LEFT)]->has('DESPACHADO')): ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '4'])); ?>">
                                            <?php echo e($total += count($estados[str_pad($i, 2, "0", STR_PAD_LEFT)]['DESPACHADO'])); ?>

                                        </a>
                                    </td>
                                <?php else: ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '4'])); ?>">
                                            0
                                        </a>
                                    </td>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <td><?php echo e($total); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Entregado</th>
                            <?php
                                $total = 0;
                            ?>
                            <?php for($i = 1; $i < 13; $i++): ?>
                                <?php if($estados->has(str_pad($i, 2, "0", STR_PAD_LEFT)) && $estados[str_pad($i, 2, "0", STR_PAD_LEFT)]->has('ENTREGADO')): ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '5'])); ?>">
                                            <?php echo e($total += count($estados[str_pad($i, 2, "0", STR_PAD_LEFT)]['ENTREGADO'])); ?>

                                        </a>
                                    </td>
                                <?php else: ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '5'])); ?>">
                                            0
                                        </a>
                                    </td>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <td><?php echo e($total); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Rechazado</th>
                            <?php
                                $total = 0;
                            ?>
                            <?php for($i = 1; $i < 13; $i++): ?>
                                <?php if($estados->has(str_pad($i, 2, "0", STR_PAD_LEFT)) && $estados[str_pad($i, 2, "0", STR_PAD_LEFT)]->has('RECHAZADO')): ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '6'])); ?>">
                                            <?php echo e($total += count($estados[str_pad($i, 2, "0", STR_PAD_LEFT)]['RECHAZADO'])); ?>

                                        </a>
                                    </td>
                                <?php else: ?>
                                    <td>
                                        <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '6'])); ?>">
                                            0
                                        </a>
                                    </td>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <td><?php echo e($total); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/requerimiento/index/index_mes.blade.php ENDPATH**/ ?>