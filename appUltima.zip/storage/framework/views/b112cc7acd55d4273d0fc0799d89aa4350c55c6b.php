<?php $__env->startSection('title', 'Validar Ordenes de Pedido'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">

        <div class="card">
            <?php if(count($centros) > 0): ?>
                <div class="card-header">
                    <div class="d-flex flex-row">
                        <div class="btn-group" role="group" aria-label="Validar Pedidos">
                            <validar-pedidos-component action="<?php echo e(route('pedidos.aceptarTodos')); ?>" :todos="true">Aceptar Todos</validar-pedidos-component>
                            <validar-pedidos-component action="<?php echo e(route('pedidos.rechazarTodos')); ?>" :todos="true" :validacion="false">Rechazar Todos</validar-pedidos-component>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="card-body">
                <?php if(count($centros) > 0): ?>
                    <tabs>
                    <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tab title="<?php echo e($centro->nombre); ?>">
                        <table id="datatable" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Nombre</th>
                                    <th scope="col">Estado</th>
                                    <th scope="col">Ver</th>
                                    <th scope="col">Aceptar</th>
                                    <th scope="col">Rechazar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $centro->requerimientos()->where('estado', 'ESPERANDO VALIDACION')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><a href="<?php echo e(route('pedidos.show', $requerimiento)); ?>"><?php echo e($requerimiento->nombre); ?></a></td>
                                        <td><?php echo e($requerimiento->estado); ?></td>
                                        <td class="d-flex flex-row">
                                            <modal-btn-component
                                                title="Orden de Pedido"
                                                :message='[
                                                { data:
                                                <?php echo json_encode($requerimiento->productos, 15, 512) ?>,
                                                type: "Array", keys: ["sku",
                                                "detalle",
                                                "pivot"], pivot: "cantidad"},
                                                { data: <?php echo json_encode(["total" => "$" . number_format($requerimiento->getTotal()) ], 15, 512) ?>, type: "Object", keys: ["total"]}
                                                ]'>Ver Orden de Pedido</modal-btn-component>
                                            </modal-btn-component>
                                        </td>
                                        <td>
                                            <validar-pedidos-component
                                                action="<?php echo e(route('pedidos.aceptar')); ?>"
                                                :todos="false" :pedido='<?php echo e($requerimiento->id); ?>'>Aceptar</validar-pedidos-component>
                                        </td>
                                        <td>
                                            <validar-pedidos-component
                                                action="<?php echo e(route('pedidos.rechazar')); ?>"
                                                :todos="false" :validacion="false" :pedido='<?php echo e($requerimiento->id); ?>'>Rechazar</validar-pedidos-component>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        </tab>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tabs>
                <?php else: ?>
                    <div class="alert alert-dark">No hay Ordenes de Pedidos pendientes</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php if(\Session::has('msg')): ?>
        <?php
            $msg = \Session::get('msg')
        ?>
        <script charset="utf-8">
            (Swal.fire({
                icon: "success",
                title: "<?php echo e($msg['title']); ?>",
                text: "<?php echo e($msg['text']); ?>"
            }))()
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mline-siger/resources/views/requerimiento/validar_pedidos.blade.php ENDPATH**/ ?>