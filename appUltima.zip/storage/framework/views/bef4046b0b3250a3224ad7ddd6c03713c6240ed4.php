<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="container">
  <div class="card">
    <div class="card-header font-bold text-xl"><?php echo e($empresa->razon_social); ?>: Lista de productos</div>
    <div class="card-body">
      <a class="btn btn-info mb-3" href="<?php echo e(route('empresas.productos.create', $empresa)); ?>">Cargar Productos</a>
      <form action="<?php echo e(route('empresas.productos.show', $empresa)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary mb-3 ml-3">Exportar a Excel</button>
      </form>
      <index-component :headers="[
                                     { text: 'SKU', value: 'sku' },
                                     { text: 'Familia', value: 'familia' },
                                     { text: 'Detalle', value: 'detalle' },
                                     { text: 'Marca', value: 'marca' },
                                     { text: 'Costo', value: 'costo' },
                                     { text: 'Venta', value: 'venta' },
                                     { text: 'Desde', value: 'desde' },
                                     { text: 'Hasta', value: 'hasta' },
                                     { text: 'Reemplazo', value: 'reemplazo' },
                                     ]" :items='<?php echo json_encode($productos, 15, 512) ?>'></index-component>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/control/productos/index.blade.php ENDPATH**/ ?>