<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>" />
<div class="container">
  <div class="card">
    <div class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Programar Despachos</div>
    <div class="card-body">
      <?php if($requerimientos->count() > 0): ?>

      <!-- <header>
  <h1>Valida RUT</h1>
  <p>Algoritmo de validaciónd del rut Chileno</p>
</header> -->

<a class="btn btn-secondary" style="color: #fff;"  href="<?php echo e(route('compass.home')); ?>">Pagina anterior</a>

<form class="container" action="<?php echo e(route('compass.pedidos.programarDespachos')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
          
          <div class="col-md-6">
            <div class="form-group form-row">
              <label class="col-md col-form-label text-right" for="nombre">Nombre Transportista:</label>
              <span class="col-md">
                <input class="form-control
                                       <?php $__errorArgs = ['nombre_chofer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre_chofer" type="text">
                <?php $__errorArgs = ["nombre_chofer"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </span>
            </div>
            <div class="form-group form-row">
              <label class="col-md col-form-label text-right" for="rut">RUT Transportista:</label>
              <span class="col-md">
                <input class="form-control" name="rut_chofer" pattern="\d{7,8}-[0-9kK]{1}" type="text" id="rut_chofer">
                <?php $__errorArgs = ["rut_chofer"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <small class="text-muted">Sin puntos. Ej: 46656975-4</small>
              </span>
            </div>
            <div class="form-group form-row">
              <label class="col-md col-form-label text-right" for="contacto">Contacto Transportista:</label>
              <span class="col-md">
                <input class="form-control
                                       <?php $__errorArgs = ['contacto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                       is-invalid
                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="contacto" type="text">
                <?php $__errorArgs = ["contacto"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </span>
            </div>
            <div class="form-group form-row">
              <label class="col-md col-form-label text-right" for="contacto">Rut Empresa:</label>
              <span class="col-md">
                <input class="form-control
                                     <?php $__errorArgs = ['rut_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     is-invalid
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" pattern="\d{7,8}-[0-9kK]{1}" name="rut_empresa" type="text" id="rut_empresa">
                <small class="text-muted">Sin puntos. Ej: 46656975-4</small>
                <?php $__errorArgs = ["rut_empresa"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </span>
            </div>
           
            
            
           
            <div class="form-group form-row">
              <div class="col-md-4 mx-auto" id="registrar"><button class="btn btn-ve" type="submit">Programar Despacho</button></div>
            </div>
          </div>
          <div class="col">
            <div class="form-group form-row">
              <label class="col-md col-form-label text-right" for="contacto">Patente:</label>
              <span class="col-md">
                <input class="form-control
                                     <?php $__errorArgs = ['patente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     is-invalid
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="patente" type="text">
                <?php $__errorArgs = ["patente"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </span>
            </div>
            <div class="form-group form-row">
              <label class="col-md col-form-label text-right" for="fecha">Fecha de Despacho:</label>
              <span class="col-md">
                <input class="form-control
                                       <?php $__errorArgs = ['fecha_programada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                       is-invalid
                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fecha_programada" type="date">
                <?php $__errorArgs = ["fecha_programada"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </span>
            </div>
            <div class="form-group form-row">
              <label class="col-md col-form-label text-right" for="destino">Punto de Abastecimiento</label>
              <span class="col-md">
                <select class="form-control
                                         <?php $__errorArgs = ['abastecimiento_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                         is-invalid
                                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="abastecimiento_id">
                  <?php $__currentLoopData = $abastecimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abastecimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($abastecimiento->id); ?>"><?php echo e($abastecimiento->nombre); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ["abastecimiento_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </span>
            </div>
            </div>

          
        </div>
        <div class="row">
          <div class="col container table-sm">
            <?php $__errorArgs = ["requerimientos"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
              <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <table class="table table-sm table-striped table-bordered" id="datatable">
              <thead>
                <tr>
                  <th scope="col" >Seleccionar</th>
                  <th scope="col">#</th>
                  <th scope="col">Nombre</th>
                  <th scope="col">Centro</th>
                  <th scope="col">Empresa</th>
                  <th scope="col">Fecha de Solicitud</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $requerimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" value="<?php echo e($requerimiento->id); ?>" name="requerimientos[]">
                      <label class="form-check-label">
                        Incluir
                      </label>
                    </div>
                  </td>
                  <th scope="row"><?php echo e($requerimiento->id); ?></th>
                  <td><?php echo e($requerimiento->nombre); ?></td>
                  <td><?php echo e($requerimiento->centro->nombre); ?></td>
                  <td><?php echo e($requerimiento->centro->empresa->razon_social); ?></td>
                  <td><?php echo e($requerimiento->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </form>
      <?php else: ?>
      <div class="alert alert-dark">Sin <a class="alert-link" href="<?php echo e(route('compass.pedidos.cajasIndex')); ?>">Cajas</a> disponibles para despachar</div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
  var Fn = {
  // Valida el rut con su cadena completa "XXXXXXXX-X"
  validaRut : function (rutCompleto) {
    rutCompleto = rutCompleto.replace("‐","-");
    if (!/^[0-9]+[-|‐]{1}[0-9kK]{1}$/.test( rutCompleto ))
      return false;
    var tmp   = rutCompleto.split('-');
    var digv  = tmp[1]; 
    var rut   = tmp[0];
    if ( digv == 'K' ) digv = 'k' ;
    
    return (Fn.dv(rut) == digv );
  },
  dv : function(T){
    var M=0,S=1;
    for(;T;T=Math.floor(T/10))
      S=(S+T%10*(9-M++%6))%11;
    return S?S-1:'k';
  }
}
$(document).ready(function(){
  document.getElementById("rut_chofer").addEventListener('keyup', validarFormulario); 
  document.getElementById("rut_empresa").addEventListener('keyup', validarFormulario1); 
});

function validarFormulario(evento) {
  
  //var usuario = document.getElementById('rut_chofer').value;
  document.getElementById("registrar").innerHTML = ''
  let condicion =document.getElementById("registrar")
  let elemento = document.getElementById("rut_chofer");

  if (Fn.validaRut( $("#rut_chofer").val() ) ){
    //document.getElementById("rut1").innerHTML = ''
    //elemento.classList.remove('is-invalid');
     condicion.innerHTML +=`
     <button class="btn btn-ve" type="submit"  >Programar Despacho</button>
      `
    alert('El rut es válido');
  } else {
   // alert('La clave no es válida');
   
    //elemento.className += " is-invalid";
    let elemento1 = document.getElementById("rut1");
    // elemento1.innerHTML +=` <div class="alert alert-danger">
    //               Rut invalido
    //             </div>`
    
     condicion.innerHTML +=`
     <button class="btn btn-ve" type="submit" disabled >Programar Despacho</button>
     `
    
         // alert('La clave no es válida');
          //window.history.back();
    
  }

  





  // var clave = document.getElementById('clave').value;
  // if (clave.length < 6) {
  //   alert('La clave no es válida');
  //   return;
  // }
  //this.submit();
}

function validarFormulario1(evento) {
  
  //var usuario = document.getElementById('rut_chofer').value;
  document.getElementById("registrar").innerHTML = ''
  let condicion1 =document.getElementById("registrar")
  let elemento = document.getElementById("rut_empresa");

  if (Fn.validaRut( $("#rut_empresa").val() ) ){
    //document.getElementById("rut1").innerHTML = ''
    //elemento.classList.remove('is-invalid');
     condicion1.innerHTML +=`
      <div class="col-md-4 mx-auto"><button class="btn btn-ve" type="submit"  >Programar Despacho</button></div>
      `
    alert('el rut es válido');
  } else {
   // alert('La clave no es válida');
   
    //elemento.className += " is-invalid";
    let elemento1 = document.getElementById("rut1");
    // elemento1.innerHTML +=` <div class="alert alert-danger">
    //               Rut invalido
    //             </div>`
    
     condicion1.innerHTML +=`
     <div class="col-md-4 mx-auto"><button class="btn btn-ve" type="submit" disabled >Programar Despacho</button></div>
     `
    
         // alert('La clave no es válida');
          //window.history.back();
    
  }

  





  // var clave = document.getElementById('clave').value;
  // if (clave.length < 6) {
  //   alert('La clave no es válida');
  //   return;
  // }
  //this.submit();
}






  </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/compass/programar_despachos.blade.php ENDPATH**/ ?>