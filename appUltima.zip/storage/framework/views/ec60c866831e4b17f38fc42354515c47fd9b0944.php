<?php $__env->startSection('title', 'Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
<?php $__env->startSection('home-route', route('compass.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="card">
        <h3 class="card-header font-bold text-xl">
            <?php $__currentLoopData = $tipoObservaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $observacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($observacion->nombre); ?> /
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </h3>
        <div class="card-body">
            <span>
                <b>Requerimiento:</b>
                <?php echo e($guiaDespacho->requerimiento->id); ?>

            </span>
            <span>
                <b>Guia Despacho:</b>
                <?php echo e($guiaDespacho->folio); ?>

            </span>
            <span>
                <b>Centro:</b>
                <?php echo e($guiaDespacho->nombre_centro); ?>

            </span>
            <span>
                <b>Area:</b>
                <?php echo e($guiaDespacho->nombre_centro); ?>

            </span>
            <div class="container mt-2 table-responsive">
                <concepto-component :guia-despacho='<?php echo json_encode($guiaDespacho, 15, 512) ?>' :productos='<?php echo json_encode($productos, 15, 512) ?>' :observaciones='<?php echo json_encode($observaciones, 15, 512) ?>' <?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
                    actualizacion-route="<?php echo e($actualizacionRoute); ?>"
                    store-route="<?php echo e($storeRoute); ?>"
                    massive-route="<?php echo e(route("estado_pago_concepto_masivo", $guiaDespacho)); ?>"
                    <?php else: ?>
                    :genera-reclamos="true"
                    reclamo-route="<?php echo e(route("estado_pago_reclamo", [$guiaDespacho])); ?>"
                    <?php endif; ?>
                    >
                </concepto-component>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/estado_pago/concepto.blade.php ENDPATH**/ ?>