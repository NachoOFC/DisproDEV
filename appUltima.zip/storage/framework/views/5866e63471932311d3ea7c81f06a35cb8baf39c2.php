<?php $__env->startSection('title', 'Crear Orden de Pedido | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="card">
        <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->userable->nombre); ?>: Nueva Orden de Pedido</h3>
        <div class="card-body">
          <div class="row justify-content-center align-items-center">
            <div class="col-md-10">
                <requerimiento-generation-component
                    formato-download="<?php echo e(route('requerimientos.formato')); ?>"
                    :productos='<?php echo json_encode($productos, 15, 512) ?>'
                    :empresa='<?php echo json_encode($empresa, 15, 512) ?>'
                    :centro='<?php echo json_encode($centro, 15, 512) ?>'
                    nombre-requerimiento="<?php echo e($nombre); ?>"
                    numero-requerimiento="<?php echo e($numeroRequerimiento); ?>"
                    store-route="<?php echo e(route('requerimientos.store')); ?>"
                ></requerimiento-generation-component>
            </div>

          </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/requerimiento/create.blade.php ENDPATH**/ ?>