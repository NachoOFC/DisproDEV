<?php $__env->startSection('title', 'Lista de Ordenes | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
<?php $__env->startSection('home-route', route('compass.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>


<?php $__env->startSection('main'); ?>
<div class="container">
<input type="button"  class="btn btn-secondary" value="Página anterior" onClick="history.go(-1);">

    <div class="card">
        <h3 class="card-header font-bold text-xl">Lista de Ordenes de Pedido</h3>
        <div class="card-body">
            <h5 class="card-title h4 text-center border-bottom"><?php echo e($centro->nombre); ?></h5>
            <table id="datatable" class="table">
                <thead>
                    <tr>
                        <th scope="col">Folio</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Estado</th>
                        <?php if((Auth::user()->userable instanceof \App\Centro)): ?>
                        <th scope="col">Libreria</th>
                        <?php endif; ?>
                        <th scope="col">Fecha de Creacion</th>
                        <th scope="col">Accion</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $requerimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if( $requerimiento->estado != 'ELIMINADO'): ?>
                    <tr>
                        <td>
                            <a
                                href="<?php echo e(route('pedidos.show', $requerimiento)); ?>"
                            >
                                <?php echo e($requerimiento->folio->implode(",")); ?>

                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('pedidos.show', $requerimiento)); ?>"><?php echo e($requerimiento->nombre); ?></a>
                        </td>
                        <td><div><?php echo e($requerimiento->estado); ?></div></td>
                        <?php if((Auth::user()->userable instanceof \App\Centro)): ?>
                        <td>
                            <agregar-libreria-component action="<?php echo e(route('libreria.editar', $requerimiento)); ?>" :library='<?php echo json_encode(Auth::user()->hasRequerimiento($requerimiento), 15, 512) ?>'></agregar-libreria-component>
                        </td>
                        <?php endif; ?>
                        <td>
                            <?php echo e($requerimiento->created_at); ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <div style="margin-right: 10px; ">
                                <modal-btn-component title="Orden de Pedido" :message='[
                                            { data:
                                            <?php echo json_encode($requerimiento->productos, 15, 512) ?>,
                                            type: "Array", keys: ["sku",
                                            "detalle",
                                            "pivot"], pivot: "cantidad"},
                                            { data: <?php echo json_encode(["total" => "$" . number_format($requerimiento->getTotal()) ], 15, 512) ?>, type: "Object", keys: ["total"]}
                                            ]'>Ver Orden de Pedido</modal-btn-component>
                                            </div>
                                <?php if(Auth::user()->userable instanceof \App\Centro): ?>
                                <?php if( $requerimiento->estado === 'DESPACHADO'): ?>
                                <a class="btn btn-success" href="<?php echo e(route('pedidos.entregado', $requerimiento)); ?>">Recibido</a>
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php if( $requerimiento->estado === 'RECIBIDO CON OBSERVACIONES'): ?>
                                <a class="btn btn-outline-info" href="<?php echo e(route(
                                                                    'rechazos.show',
                                                                    $requerimiento)); ?>">
                                    Ver Observaciones
                                </a>
                                <?php endif; ?>
                                <?php if( $requerimiento->estado === 'DESPACHADO'): ?>
                                <modal-btn-component title="Orden de Pedido" :message='[
                                                { data: <?php echo json_encode([
                                                "nombre" => $requerimiento->nombre_transportista, "rut" => $requerimiento->rut_transportista, "contacto" => $requerimiento->contacto_transportista
                                                ]) ?>
                                                , type: "Object", keys: ["nombre",
                                                "rut", "contacto"]}
                                                ]'>Ver Transporte</modal-btn-component>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/requerimiento/index/show.blade.php ENDPATH**/ ?>