<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl">
                Lista de Productos de <?php echo e($empresa->razon_social); ?>

            </h3>
            <div class="card-body">
                <div class="container mt-2">
                    <div class="dropdown mb-4">
                        <button
                            class="btn btn-secondary dropdown-toggle"
                            type="button"
                            id="dropdownMenuButton"
                            data-toggle="dropdown"
                            aria-haspopup="true"
                            aria-expanded="false">
                            Escoge la Empresa
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a
                                class="dropdown-item"
                                href="<?php echo e(route('productos.indexEmpresa', $item)); ?>">
                                    <?php echo e($item->razon_social); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table id="datatable" class="table table-sm">
                            <thead>
                                <tr>
                                    <th scope="col">SKU</th>
                                    <th scope="col">Detalle</th>
                                    <th scope="col">Precio Costo</th>
                                    <th scope="col">Precio Venta</th>
                                    <th scope="col">Accion</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($producto->sku); ?></td>
                                        <td><?php echo e($producto->detalle); ?></td>
                                        <td><?php echo e($producto->costo); ?></td>
                                        <td><?php echo e($producto->pivot->precio); ?></td>
                                        <td>
                                            <a class="btn btn-primary" href="<?php echo e(route('productos.edit', $producto)); ?>"><i class="fas fa-edit"></i></a>
                                            <delete-btn-component action="<?php echo e(route('productos.destroy', $producto)); ?>"></delete-btn-component>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mline-siger/resources/views/compass/producto/index_empresa.blade.php ENDPATH**/ ?>