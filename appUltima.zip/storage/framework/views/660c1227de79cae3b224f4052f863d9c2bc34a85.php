<?php $__env->startSection('title', 'Estado Observacion | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
<?php $__env->startSection('home-route', route('compass.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="card">
        <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Cuadro de estado de observaciones a recepciones</h3>
        <div class="card-body">
            <div class="container mt-2">
                <form class="flex flex-row items-end" method="POST" action="<?php echo e(route("generate_estado_general")); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($empresas) && count($empresas) > 0): ?>
                    <div class="flex flex-col">
                        <label for="">Empresa:</label>
                        <select class="form-control" name="empresa_id" required>
                            <option>Seleccione una empresa</option>
                            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($empresa->id); ?>"><?php echo e($empresa->razon_social); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    <div class="flex flex-col mx-2">
                        <label for="">Desde:</label>
                        <input type="date" name="inicio" class="form-control" required />
                    </div>

                    <div class="flex flex-col">
                        <label for="">Hasta:</label>
                        <input type="date" name="fin" class="form-control" required />
                    </div>
                    <div class="flex flex-col mx-2">
                        <button type="submit" class="btn btn-primary">Ver Guias</button>
                    </div>

                </form>
            </div>
            <?php if(isset($aceptadas) || isset($rechazadas) || isset($observadas)): ?>
            <div class="container mt-2">
                <v-expansion-panels>
                    <?php if(isset($aceptadas)): ?>
                    <v-expansion-panel>
                        <v-expansion-panel-header>Aceptadas</v-expansion-panel-header>
                        <v-expansion-panel-content>
                            <div class="table-responsive">
                                <table id="datatable" class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th scope="col">ID OP</th>
                                            <th scope="col">ID GUIA</th>
                                            <th scope="col">CENTRO</th>
                                            <th scope="col">FECHA</th>
                                            <th scope="col">MONTO</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $aceptadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($guia->requerimiento_id); ?></td>
                                            <td><?php echo e($guia->folio); ?></td>
                                            <td><?php echo e($guia->nombre_centro); ?></td>
                                            <td><?php echo e($guia->fecha); ?></td>
                                            <td><?php echo e(number_format($guia->neto, 0)); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </v-expansion-panel-content>
                    </v-expansion-panel>
                    <?php endif; ?>
                    <?php if(isset($rechazadas)): ?>
                    <v-expansion-panel>
                        <v-expansion-panel-header>Rechazadas</v-expansion-panel-header>
                        <v-expansion-panel-content>
                            <div class="table-responsive">
                                <table id="datatable" class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th scope="col">ID OP</th>
                                            <th scope="col">ID GUIA</th>
                                            <th scope="col">CENTRO</th>
                                            <th scope="col">FECHA</th>
                                            <th scope="col">MONTO</th>
                                            <th scope="col">PRODUCTOS <br /> FALTANTES (PARCIAL)</th>
                                            <th scope="col">PRODUCTOS <br /> FALTANTES (TOTAL)</th>
                                            <th scope="col">TOTAL RECHAZADAS</th>
                                            <th scope="col">SIN LIQUIDAR</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $aceptadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(($guia->getObservacionesCountById(2) + $guia->getObservacionesCountById(3)) > 0): ?>
                                        <tr>
                                            <td><?php echo e($guia->requerimiento_id); ?></td>
                                            <td><?php echo e($guia->folio); ?></td>
                                            <td><?php echo e($guia->nombre_centro); ?></td>
                                            <td><?php echo e($guia->fecha); ?></td>
                                            <td class="text-center"><?php echo e(number_format($guia->neto, 0)); ?></td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route("estado_pago_concepto", ["guiaDespacho" => $guia, "concepto" => "3"])); ?>" target="_blank">
                                                    <?php echo e($guia->getObservacionesCountById(3)); ?>

                                                </a>
                                            </td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route("estado_pago_concepto", ["guiaDespacho" => $guia, "concepto" => "2"])); ?>" target="_blank">
                                                    <?php echo e($guia->getObservacionesCountById(2)); ?>

                                                </a>
                                            </td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route("estado_pago_concepto", ["guiaDespacho" => $guia, "concepto" => "2,3"])); ?>" target="_blank">
                                                    <?php echo e($guia->getObservacionesCountById(2) +  $guia->getObservacionesCountById(3)); ?>

                                                </a>
                                            </td>
                                            <td class="text-center">
                                                <?php echo e($guia->getNoLiquidadosRechazados()); ?>

                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </v-expansion-panel-content>
                    </v-expansion-panel>
                    <?php endif; ?>
                    <?php if(isset($observadas)): ?>
                    <v-expansion-panel>
                        <v-expansion-panel-header>Recibidas con Observaciones</v-expansion-panel-header>
                        <v-expansion-panel-content>
                            <div class="table-responsive">
                                <table id="datatable" class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th scope="col">ID OP</th>
                                            <th scope="col">ID GUIA</th>
                                            <th scope="col">CENTRO</th>
                                            <th scope="col">FECHA</th>
                                            <th scope="col">MONTO</th>
                                            <th scope="col">PRODUCTOS EN MAL ESTADO</th>
                                            <th scope="col">PRODUCTOS VENCIDOS</th>
                                            <th scope="col">PRODUCTOS POR VENCER</th>
                                            <th scope="col">ENVASES DETERIORADOS</th>
                                            <th scope="col">TOTAL OBSERVADAS</th>
                                            <th scope="col">SIN LIQUIDAR</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $aceptadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(($guia->getObservacionesCountById(4) + $guia->getObservacionesCountById(5) + $guia->getObservacionesCountById(6) + $guia->getObservacionesCountById(7)) > 0): ?>
                                        <tr>
                                            <td><?php echo e($guia->requerimiento_id); ?></td>
                                            <td><?php echo e($guia->folio); ?></td>
                                            <td><?php echo e($guia->nombre_centro); ?></td>
                                            <td><?php echo e($guia->fecha); ?></td>
                                            <td class="text-center"><?php echo e(number_format($guia->neto, 0)); ?></td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route("estado_pago_concepto", ["guiaDespacho" => $guia, "concepto" => "4"])); ?>" target="_blank">
                                                    <?php echo e($guia->getObservacionesCountById(4)); ?>

                                                </a>
                                            </td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route("estado_pago_concepto", ["guiaDespacho" => $guia, "concepto" => "5"])); ?>" target="_blank">
                                                    <?php echo e($guia->getObservacionesCountById(5)); ?>

                                                </a>
                                            </td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route("estado_pago_concepto", ["guiaDespacho" => $guia, "concepto" => "6"])); ?>" target="_blank">
                                                    <?php echo e($guia->getObservacionesCountById(6)); ?>

                                                </a>
                                            </td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route("estado_pago_concepto", ["guiaDespacho" => $guia, "concepto" => "7"])); ?>" target="_blank">
                                                    <?php echo e($guia->getObservacionesCountById(7)); ?>

                                                </a>
                                            </td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route("estado_pago_concepto", ["guiaDespacho" => $guia, "concepto" => "4,5,6,7"])); ?>" target="_blank">
                                                    <?php echo e($guia->getObservacionesCountById(4) + $guia->getObservacionesCountById(5) + $guia->getObservacionesCountById(6) + $guia->getObservacionesCountById(7)); ?>

                                                </a>
                                            </td>
                                            <td class="text-center">
                                                <?php echo e($guia->getNoLiquidadosObservados()); ?>

                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </v-expansion-panel-content>
                    </v-expansion-panel>
                    <?php endif; ?>
                </v-expansion-panels>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/estado_pago/general.blade.php ENDPATH**/ ?>