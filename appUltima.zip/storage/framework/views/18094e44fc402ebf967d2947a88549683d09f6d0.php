<?php $__env->startSection('title', 'Reporte | MLine SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl">
                <?php echo e(Auth::user()->getNombreRelacionado()); ?>:
                Productos que generan nota de credito
            </h3>
            <div class="card-body">
                <div class="d-flex flex-row mb-2">
                </div>
                <div class="container mt-2">
                    <form action="<?php echo e(route('reportes.nota-credito.generar')); ?>"
                          method="POST" accept-charset="utf-8">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label class="col-sm-2" for="inicio">Fecha de Inicio:</label>
                            <span class="col-sm-6">
                                <input class="form-control" required type="date" name="inicio">
                                <p class="text-muted">Obligatorio</p>
                            </span>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2" for="fin">Fecha de Fin:</label>
                            <span class="col-sm-6">
                                <input class="form-control" required type="date" name="fin">
                                <p class="text-muted">Obligatorio</p>
                            </span>
                        </div>

                        <button class="btn btn-primary">Generar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/reporte/nota-credito.blade.php ENDPATH**/ ?>