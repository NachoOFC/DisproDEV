<?php $__env->startSection('title', 'Verificar Pedidos'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl">Verificar Ordenes de Pedidos</h3>
            <div class="card-body">
                <?php if($productos->count() > 0 || $requerimientos->count() > 0): ?>
                    <div class="d-flex flex-row mb-2">
                        <form action="<?php echo e(route('compass.verificar')); ?>" method="POST" accept-charset="utf-8">
                            <?php echo csrf_field(); ?>

                            <button class="btn btn-primary">Enviar todo a Bodega</button>
                        </form>
                    </div>
                    <div class="container mt-2">
                        <div class="table-responsive">
                            <table id="datatable" class="table table-sm">
                                <thead>
                                    <tr>
                                        <th scope="col">SKU</th>
                                        <th scope="col">Detalle</th>
                                        <th scope="col">Cantidad Solicitada</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($producto->sku); ?></td>
                                            <td><?php echo e($producto->detalle); ?></td>
                                            <td><?php echo e($producto->cantidad); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="container mt-2">
                        <div class="table-responsive">
                            <form action="" method="POST">
                                <?php echo csrf_field(); ?>

                                <button class="btn btn-primary">Enviar seleccionados a Bodega</button>
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th scope="col">Bodega</th>
                                            <th scope="col">Folio</th>
                                            <th scope="col">Nombre</th>
                                            <th scope="col">Empresa</th>
                                            <th scope="col">Centro</th>
                                            <th scope="col">Productos</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $requerimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" name="seleccionados">
                                                        <label class="form-check-label">
                                                            Enviar
                                                        </label>
                                                        <input type="hidden" value="<?php echo e($requerimiento->id); ?>" name="requerimientos[]"/>
                                                    </div>
                                                </td>
                                                <td><?php echo e($requerimiento->id); ?></td>
                                                <td><?php echo e($requerimiento->nombre); ?></td>
                                                <td><?php echo e($requerimiento->centro->empresa->razon_social); ?></td>
                                                <td><?php echo e($requerimiento->centro->nombre); ?></td>
                                                <td>
                                    <a href="<?php echo e(route('pedidos.show', $requerimiento)); ?>"><?php echo e($requerimiento->nombre); ?></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-dark">No hay ordenes de pedidos pendientes</div>

                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mline-siger/resources/views/compass/verificar_index.blade.php ENDPATH**/ ?>