<?php $__env->startSection('title', 'Editar Estado de la Empresa | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\Empresa)): ?>
  <?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php elseif(Auth::user()->userable instanceof \App\CompassRole): ?>
    <?php $__env->startSection('home-route', route('compass.home')); ?>
<?php endif; ?>

<?php $__env->startSection('nav-menu'); ?>
  <?php if((Auth::user()->userable instanceof \App\Empresa)): ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php elseif(Auth::user()->userable instanceof \App\CompassRole): ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
  <div class="container">
    <div class="card">
      <h3 class="card-header font-bold text-xl">Editar Estado</h3>
      <div class="card-body">
        <form action="<?php echo e(route('empresas.habilitar', $empresa)); ?>" method="POST" accept-charset="utf-8">
          <?php echo csrf_field(); ?>

          <div class="form-group row">
            <label class="col-sm-2" for="razon_social">Razon Social:</label>
            <span class="col-sm-6">
              <input class="form-control-plaintext" type="text" value="<?php echo e($empresa->razon_social); ?>" disabled>
            </span>
          </div>

          <div class="form-group row">
            <label class="col-sm-2" for="rut">RUT:</label>
            <span class="col-sm-6">
              <input class="form-control-plaintext" type="text" value="<?php echo e($empresa->rut); ?>" disabled>
            </span>
          </div>

          <div class="form-group row">
            <label class="col-sm-2" for="rut">Estado:</label>
            <span class="col-sm-6">
              <select name="estado" class="form-control">
                <option <?php if(!isset($empresa->habilitado)): ?> selected <?php endif; ?> value="null">Segun Horario asignado</option>
                  <option <?php if(isset($empresa->habilitado) && (!$empresa->habilitado)): ?> selected <?php endif; ?>  value="false">Inhabilitado</option>
                    <option <?php if(isset($empresa->habilitado) && ($empresa->habilitado)): ?>  selected <?php endif; ?> value="true">Habilitado</option>
              </select>
            </span>
          </div>


          <div class="form-group row">
            <div class="col-sm-10">
              <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mline-siger/resources/views/empresa/estado.blade.php ENDPATH**/ ?>