<?php $__env->startSection('title', 'Conciliacion | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
<?php $__env->startSection('home-route', route('compass.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="card">
        <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Conciliacion OC/NC por EP</h3>
        <div class="card-body">
            <div class="container mt-2">
                <div class="d-flex flex-column mb-4">
                    <span>
                        <b>Liquidacion:</b>
                        $ <?php echo e(number_format($cierre->monto, 0)); ?>

                    </span>
                    <span>
                        <b>Factura:</b>
                        <a href="#" data-toggle="modal" data-target="#modalResumenFacturas">
                            $ <?php echo e(number_format($totalFacturasElectronica, 0)); ?>

                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="modalResumenFacturas" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="myModalLabel">Resumen Facturas Electronicas</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-sm">
                                            <thead>
                                                <th>Fecha</th>
                                                <th>Folio</th>
                                                <th>Monto</th>
                                                <th>PDF</th>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $facturasElectronica; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($factura->fecha); ?></td>
                                                    <td><?php echo e($factura->folio); ?></td>
                                                    <td>$ <?php echo e(number_format($factura->monto, 0)); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(asset($factura->documento)); ?>" target="_BLANK">Ver PDF</a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </span>
                    <span>
                        <b>Orden de Compra:</b>
                        <a href="#" data-toggle="modal" data-target="#modalResumenOC">
                            $ <?php echo e(number_format($totalOrdenesCompra, 0)); ?>

                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="modalResumenOC" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="myModalLabel">Resumen Ordenes de Compra</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-sm">
                                            <thead>
                                                <th>Fecha</th>
                                                <th>Folio</th>
                                                <th>Monto</th>
                                                <th>PDF</th>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $ordenesCompra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($orden->fecha); ?></td>
                                                    <td><?php echo e($orden->folio); ?></td>
                                                    <td>$ <?php echo e(number_format($orden->monto, 0)); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(asset($orden->documento)); ?>" target="_BLANK">Ver PDF</a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </span>
                    <span>
                        <b>Notas de Credito:</b>
                        <a href="#" data-toggle="modal" data-target="#modalResumenNC">
                            $ <?php echo e(number_format($totalNotasCredito, 0)); ?>

                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="modalResumenNC" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="myModalLabel">Resumen Notas de Credito Tributaria</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-sm">
                                            <thead>
                                                <th>Fecha</th>
                                                <th>Folio</th>
                                                <th>Monto</th>
                                                <th>PDF</th>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $notasCreditoTributaria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($notas->fecha); ?></td>
                                                    <td><?php echo e($notas->folio); ?></td>
                                                    <td>$ <?php echo e($notas->monto); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(asset($notas->documento)); ?>" target="_BLANK">Ver PDF</a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </span>
                </div>

                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th class="border-r text-left">RESUMEN EDP</th>
                            <th class="text-right">LIQ INTERNA</th>
                            <th class="text-right">LIQ EXTERNA</th>
                            <th class="border-r text-right">DIF. LIQ</th>
                            <th class="text-right">MONTO</th>
                            <th class="text-right">OC</th>
                            <th class="border-r text-right">DIF. MNT/OC</th>
                            <th class="text-right">NC PF</th>
                            <th class="text-right">NC T</th>
                            <th class="border-r text-right">DIF. NC</th>
                            <th class="text-right">CUADRATURA</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="border-r text-left"><?php echo e(date_format($cierre->created_at, "d/m/Y")); ?>-<?php echo e($cierre->id); ?></td>
                            <td class="text-right"><?php echo e(number_format($cierre->monto, 0)); ?></td>
                            <td class="text-right"><?php echo e(number_format($liquidacionDoc)); ?></td>
                            <td class="border-r text-right"><?php echo e(number_format($deltaLiq, 0)); ?></td>
                            <td class="text-right"><?php echo e(number_format($totalNeto, 0)); ?></td>
                            <td class="text-right"><?php echo e(number_format($totalOrdenesCompra, 0)); ?></td>
                            <td class="border-r text-right"><?php echo e(number_format($deltaNetoOC, 0)); ?></td>
                            <td class="text-right"><?php echo e(number_format($totalNotasCreditoPF, 0)); ?></td>
                            <td class="text-right"><?php echo e(number_format($totalNotasCredito, 0)); ?></td>
                            <td class="border-r text-right"><?php echo e(number_format($deltaNC, 0)); ?></td>
                            <td class="text-right"><?php echo e(number_format($cuadratura, 0)); ?></td>
                        </tr>
                    </tbody>
                </table>

                <table class="table table-sm" id="datatable">
                    <thead>
                        <tr>
                            <th class="text-right">Centro</th>
                            <th class="text-left">MONTO</th>
                            <th class="text-left">OC</th>
                            <th class="text-left">DIF. MONTO-OC</th>
                            <th class="text-left">NC PF</th>
                            <th class="text-left">NC Trib.</th>
                            <th class="text-left">DIF. NC</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $conciliacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-right"><?php echo e($centro["centro"]->nombre); ?></td>
                            <td class="text-left">$ <?php echo e(number_format($centro["neto"], 0)); ?></td>
                            <td class="text-left">
                                <a href="#" data-toggle="modal" data-target="#modalOC<?php echo e($centro["centro"]->id); ?>">
                                    $ <?php echo e(number_format($centro["ordenCompra"], 0)); ?>

                                </a>
                                <!-- Modal -->
                                <div class="modal fade" id="modalOC<?php echo e($centro["centro"]->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel">Resumen OC</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            </div>
                                            <div class="modal-body">
                                                <table class="table table-sm">
                                                    <thead>
                                                        <th>Fecha</th>
                                                        <th>Folio</th>
                                                        <th>Monto</th>
                                                        <th>PDF</th>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $centro["ordenes"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($orden->fecha); ?></td>
                                                            <td><?php echo e($orden->folio); ?></td>
                                                            <td>$ <?php echo e(number_format($orden->monto)); ?></td>
                                                            <td>
                                                                <a href="<?php echo e(asset($orden->documento)); ?>" target="_BLANK">Ver PDF</a>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="text-left">$ <?php echo e(number_format($centro["deltaNeto"], 0)); ?></td>
                            <td class="text-left">$ <?php echo e(number_format($centro["notaCreditoProforma"], 0)); ?></td>
                            <td class="text-left">
                                <a href="#" data-toggle="modal" data-target="#modalNC<?php echo e($centro["centro"]->id); ?>">
                                    $ <?php echo e(number_format($centro["notaCreditoTributaria"])); ?>

                                </a>
                                <!-- Modal -->
                                <div class="modal fade" id="modalNC<?php echo e($centro["centro"]->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel">Resumen NC Trib.</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            </div>
                                            <div class="modal-body">
                                                <table class="table table-sm">
                                                    <thead>
                                                        <th>Fecha</th>
                                                        <th>Folio</th>
                                                        <th>Monto</th>
                                                        <th>PDF</th>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $centro["notas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($nota->fecha); ?></td>
                                                            <td><?php echo e($nota->folio); ?></td>
                                                            <td>$ <?php echo e(number_format($nota->monto, 0)); ?></td>
                                                            <td>
                                                                <a href="<?php echo e(asset($nota->documento)); ?>" target="_BLANK">Ver PDF</a>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="text-left">$ <?php echo e(number_format($centro["deltaNC"], 0)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/conciliacion/conciliacion.blade.php ENDPATH**/ ?>