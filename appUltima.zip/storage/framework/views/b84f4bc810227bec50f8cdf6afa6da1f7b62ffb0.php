<?php if(count($notifications) > 0): ?>
    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div
            class="alert
            <?php if($notification->estado === 'EN BODEGA' || $notification->estado === 'PROCESAMIENTO'): ?>
                alert-info
            <?php elseif($notification->estado === 'RECHAZADO'): ?>
                alert-danger
            <?php else: ?>
                alert-primary
            <?php endif; ?>
            alert-dismissible fade show"
            role="alert">
            El Requerimiento con nombre:
            <b><?php echo e($notification->nombre); ?></b>,
            fue actualizado al estado:
            <b><?php echo e($notification->estado); ?></b>,
            a la fecha de: <b><?php echo e($notification->updated_at); ?></b>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div class="alert alert-secondary">No tienes notificaciones nuevas</div>
<?php endif; ?>
<?php /**PATH /home/jmonagas/Projects/mline-siger/resources/views/partials/notifications.blade.php ENDPATH**/ ?>