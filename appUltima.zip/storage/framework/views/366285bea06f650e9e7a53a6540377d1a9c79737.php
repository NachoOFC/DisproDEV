<?php $__env->startSection('title', 'Crear Orden de Pedido | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="card">
        <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->userable->nombre); ?>: Nueva Orden de Pedido</h3>
        <crear-requerimiento-component
            :index-productos='<?php echo json_encode($productos, 15, 512) ?>'
            presupuesto="<?php echo e($presupuesto); ?>"
            :empresa='<?php echo json_encode($empresa, 15, 512) ?>'
            :centro='<?php echo json_encode($centro, 15, 512) ?>'
            nombre="<?php echo e($nombre); ?>"
            :libreria='<?php echo json_encode($productosLibreria, 15, 512) ?>'
            ></crear-requerimiento-component>
        <form class="card-body" action="<?php echo e(route('requerimientos.store')); ?>" method="POST"></form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mline-siger/resources/views/requerimiento/edit.blade.php ENDPATH**/ ?>