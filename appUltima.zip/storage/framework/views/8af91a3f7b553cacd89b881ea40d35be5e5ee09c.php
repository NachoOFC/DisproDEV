<?php $__env->startSection('title', 'Lista de Pedidos | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
    <?php $__env->startSection('home-route', route('compass.home')); ?>
<?php else: ?>
    <?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php endif; ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php if(Auth::user()->userable instanceof \App\CompassRole): ?>
        <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
  <div class="container">
  <a class="btn btn-secondary" style="color: #fff;"  href="<?php echo e(route('pedidos.indexEmpresa')); ?>"><i class='fas fa-arrow-alt-circle-left'></i></a>

    <div class="card">
            <h3 class="card-header font-bold text-xl">Lista de Ordenes de Pedido</h3>
      <div class="card-body">
                <div class="container mt-2">
                    <div class="table-responsive">
        <table id="datatable" class="table table-sm">
          <thead>
            <tr>
              <th scope="col" rowspan="2">Nombre</th>
              <th scope="col" rowspan="2">Accion</th>
              <th class="text-center" scope="row" colspan="7">Estados</th>
            </tr>
            <tr>
              <?php $__currentLoopData = \App\Estado::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th scope="col"><?php echo e($estado->nombre); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($centro->nombre); ?></td>
                <td>
                    <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '0'])); ?>">
                        Ver Todas
                    </a>
                </td>
                <?php $__currentLoopData = \App\Estado::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td>
                    <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => $estado->id])); ?>">
                        <?php echo e(count($centro->requerimientos()->where('estado', $estado->nombre)->get())); ?>

                    </a>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        </div>
        </div>
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/alogis_dev/resources/views/requerimiento/index/centro.blade.php ENDPATH**/ ?>