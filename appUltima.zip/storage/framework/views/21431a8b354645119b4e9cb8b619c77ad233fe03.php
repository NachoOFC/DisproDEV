<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Programar Despachos</div>
            <div class="card-body">
                <?php if($requerimientos->count() > 0): ?>

                    <form class="container" action="<?php echo e(route('compass.pedidos.programarDespachos')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group form-row">
                                    <label class="col-md col-form-label text-right" for="nombre">Nombre Transportista:</label>
                                    <span class="col-md"><input class="form-control" name="nombre" type="text"></span>
                                </div>
                                <div class="form-group form-row">
                                    <label class="col-md col-form-label text-right" for="rut">RUT Transportista:</label>
                                    <span class="col-md"><input class="form-control" name="rut" type="text"></span>
                                </div>
                                <div class="form-group form-row">
                                    <label class="col-md col-form-label text-right" for="contacto">Contacto Transportista:</label>
                                    <span class="col-md"><input class="form-control" name="contacto" type="text"></span>
                                </div>
                                <div class="form-group form-row">
                                    <label class="col-md col-form-label text-right" for="fecha">Fecha de Despacho:</label>
                                    <span class="col-md"><input class="form-control" name="fecha_despacho" type="date"></span>
                                </div>
                                <div class="form-group form-row">
                                    <label class="col-md col-form-label text-right" for="destino">Punto de Abastecimiento</label>
                                    <span class="col-md">
                                        <select class="form-control" name="destino">
                                            <?php $__currentLoopData = $abastecimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abastecimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($abastecimiento->id); ?>"><?php echo e($abastecimiento->nombre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </span>
                                </div>
                                <div class="form-group form-row">
                                    <div class="col-md-4 mx-auto"><button class="btn btn-primary" type="submit">Programar Despacho</button></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col container table-sm">
                                <table class="table table-sm table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">Seleccionar</th>
                                            <th scope="col">Folio</th>
                                            <th scope="col">Nombre</th>
                                            <th scope="col">Centro</th>
                                            <th scope="col">Empresa</th>
                                            <th scope="col">Fecha de Solicitud</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $requerimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" name="seleccionados[]">
                                                        <label class="form-check-label">
                                                            Incluir
                                                        </label>
                                                        <input name="requerimientos[]" type="hidden" value="<?php echo e($requerimiento->id); ?>">
                                                    </div>
                                                </td>
                                                <th scope="row"><?php echo e($requerimiento->id); ?></th>
                                                <td><?php echo e($requerimiento->nombre); ?></td>
                                                <td><?php echo e($requerimiento->centro->nombre); ?></td>
                                                <td><?php echo e($requerimiento->centro->empresa->razon_social); ?></td>
                                                <td><?php echo e($requerimiento->created_at); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </form>
                <?php else: ?> 
                    <div class="alert alert-dark">Sin <a class="alert-link" href="<?php echo e(route('compass.pedidos.cajasIndex')); ?>">Cajas</a> disponibles para despachar</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mline-siger/resources/views/compass/programar_despachos.blade.php ENDPATH**/ ?>