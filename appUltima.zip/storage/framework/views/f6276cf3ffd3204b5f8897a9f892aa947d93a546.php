<?php $__env->startSection('title', 'Factura Electronica | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
<?php $__env->startSection('home-route', route('compass.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="card">
        <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: <?php if(isset($facturaElectronica)): ?> Editar <?php else: ?> Crear <?php endif; ?> Factura Electronica <?php if(isset($facturaElectronica)): ?> <?php echo e($facturaElectronica->folio); ?> <?php endif; ?></h3>
        <div class="card-body">
            <div class="container mt-2">
                <form method="POST" action="<?php echo e($route); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="d-flex justify-content-around">
                        <div class="d-inline-flex flex-column form-group">
                            <label for="">Fecha:</label>
                            <input required class="form-control" name="fecha" type="date" <?php if(isset($facturaElectronica)): ?> value="<?php echo e($facturaElectronica->fecha); ?>" <?php endif; ?> />
                        </div>
                        <div class="d-inline-flex flex-column form-group">
                            <label for="">Folio:</label>
                            <input required class="form-control" name="folio" type="text" <?php if(isset($facturaElectronica)): ?> value="<?php echo e($facturaElectronica->folio); ?>" <?php endif; ?> />
                        </div>
                        <div class="d-inline-flex flex-column form-group">
                            <label for="">Monto:</label>
                            <input required class="form-control" name="monto" type="text" <?php if(isset($facturaElectronica->monto)): ?> value="<?php echo e($facturaElectronica->monto); ?>" <?php endif; ?> />
                        </div>
                        <div class="d-inline-flex flex-column form-group">
                            <label for="">Documento:</label>
                            <input class="form-control" name="documento" type="file" value="" />
                        </div>

                        <button type="submit" class="btn btn-success">Guardar</button>
                    </div>

                    <div class="container">
                        <div class="row">
                            <div class="col-md-4">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>OC</th>
                                            <th>Monto</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($orden["folio"]); ?></th>
                                            <td>
                                                <input class="form-control" type="text" name="orden-<?php echo e($orden["id"]); ?>" <?php if(isset($orden["pivot"])): ?> value="<?php echo e($orden["pivot"]["monto"]); ?>" <?php endif; ?> />
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/factura_electronica/create-edit.blade.php ENDPATH**/ ?>