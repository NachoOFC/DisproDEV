<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Carga Masiva de Productos</div>
            <div class="card-body">
                <ol>
                    <li>1. Descarga el formato de Excel: 
                        <a class="dropdown-item" href="<?php echo e(route('productos.formato')); ?>" target="_blank">Aqui</a>
                    </li>
                    <li>2. Ingresa los datos en el archivo:
                        <table class="table table-bordered table-sm">
                            <tr>
                                <th scope="row">SKU</th>
                                <td>
                                    <p class="text-danger">OBLIGATORIO.</p>
                                    Valor de referencia del sistema para identificar producto.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Detalle</th>
                                <td>
                                    <p class="text-danger">OBLIGATORIO.</p>
                                    Nombre o identifacion del producto.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Precio Costo</th>
                                <td>
                                    <p class="text-danger">OBLIGATORIO.</p>
                                    Costo de ese producto.
                                </td>
                            </tr>
                        </table>
                    </li>
                    <li>3. Sube el archivo modificado aqui:
                        <form action="<?php echo e(route('productos.asignacionMasivaProductos')); ?>" method="POST"  enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-row align-items-end mt-4">
                                <div class="form-group col-md">
                                    <label for="formato">Ingrese el archivo modificado:</label>
                                    <input type="file" class="form-control-file" name="productos">
                                </div>
                            </div>
                            <div class="col-md">
                                <button class="btn btn-primary" type="submit">Guardar</button>
                            </div>
                        </form>
                    </li>
                </ol>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mline-siger/resources/views/compass/producto/carga_masiva.blade.php ENDPATH**/ ?>