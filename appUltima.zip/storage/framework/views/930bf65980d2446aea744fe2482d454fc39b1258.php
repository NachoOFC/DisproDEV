<?php if($type === 0): ?>
<table id="datatable" class="table">
    <thead>
        <tr>
            <th scope="col">Nombre</th>
            <th scope="col">Folios</th>
            <th scope="col">Estado</th>
            <?php if((Auth::user()->userable instanceof \App\Centro)): ?>
            <th scope="col">Libreria</th>
            <?php endif; ?>
            <th scope="col">Creado</th>
            <th scope="col">Actualizado</th>
            <th scope="col">Accion</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $requerimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <a href="<?php echo e(route('pedidos.show', $requerimiento)); ?>">
                    <?php echo e($requerimiento->nombre); ?>

                </a>
            </td>
            <td>
                <?php echo e($requerimiento->folio ? $requerimiento->folio->join(", ") : "N/A"); ?>

            </td>
            <td><?php echo e($requerimiento->estado); ?></td>
            <?php if((Auth::user()->userable instanceof \App\Centro)): ?>
            <td>
                <agregar-libreria-component action="<?php echo e(route('libreria.editar', $requerimiento)); ?>" :library='<?php echo json_encode(Auth::user()
                                        ->hasRequerimiento($requerimiento), 15, 512) ?>'></agregar-libreria-component>
            </td>
            <?php endif; ?>
            <td><?php echo e(date_format($requerimiento->created_at, "d-m-Y")); ?></td>
            <td><?php echo e(date_format($requerimiento->updated_at, "d-m-Y")); ?></td>
            <td>
                <div class="btn-group" role="group">
                    <?php if(Auth::user()->userable instanceof \App\Centro): ?>
                    <?php if( $requerimiento->estado === 'DESPACHADO'): ?>
                    <a class="btn btn-outline-success" href="<?php echo e(route(
                                                 'pedidos.recepcion',
                                                 $requerimiento)); ?>">
                        Recepcion de Pedido
                    </a>
                    <?php endif; ?>
                    <?php if( $requerimiento->estado === 'RECIBIDO CON OBSERVACIONES'): ?>
                    <a class="btn btn-outline-info" href="<?php echo e(route(
                                                 'rechazos.show',
                                                 $requerimiento)); ?>">
                        Ver Observaciones
                    </a>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if( $requerimiento->estado === 'DESPACHADO'): ?>
                    <modal-btn-component title="Orden de Pedido" :message='[
                                           { data: <?php echo json_encode([
                                               "nombre" => $requerimiento->transporte->nombre_chofer, "rut" => $requerimiento->transporte->rut_chofer, "contacto" => $requerimiento->transporte->contacto
                                           ]) ?>
                                           , type: "Object", keys: ["nombre",
                                           "rut", "contacto"]}
                                           ]'>
                        Ver Transporte
                    </modal-btn-component>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php elseif($type === 1): ?>
<div class="table-responsive">
    <table id="datatable" class="table table-sm">
        <thead>
            <tr>
                <th scope="col" rowspan="2">Nombre</th>
                <th scope="col" rowspan="2">Accion</th>
                <th class="text-center" scope="row" colspan="<?php echo e(\App\Estado::all()->count()); ?>">Estados</th>
            </tr>
            <tr>
                <?php $__currentLoopData = \App\Estado::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th scope="col"><?php echo e($estado->nombre); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($centro->nombre); ?></td>
                <td>
                    <a href="<?php echo e(route('pedidos.centroIndex', ['centro' => $centro->id, 'estado' => '0'])); ?>">
                        Ver Detalles
                    </a>
                </td>
                <?php $__currentLoopData = \App\Estado::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td>
                    <?php echo e(count($centro->requerimientos()->where('estado', $estado->nombre)->get())); ?>


                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php elseif($type === 2): ?>
<div class="table-responsive">
    <table id="datatable" class="table table-sm">
        <thead>
            <tr>
                <th scope="col" rowspan="2">Nombre</th>
                <th scope="col" rowspan="2">Accion</th>
                <th class="text-center" scope="row" colspan="<?php echo e(\App\Estado::all()->count()); ?>">Estados</th>
            </tr>
            <tr>
                <?php $__currentLoopData = \App\Estado::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th scope="col"><?php echo e($estado->nombre); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($empresa->razon_social); ?></td>
                <td>
                    <a href="<?php echo e(route('pedidos.indexCentro', ['empresa' => $empresa, 'estado' => 0])); ?>">
                        Ver Todos
                    </a>
                </td>
                <?php $__currentLoopData = \App\Estado::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td>
                    <a href="<?php echo e(route('pedidos.indexCentro', ['empresa' => $empresa, 'estado' => $estado->id])); ?>">
                        <?php echo e(count($empresa->getRequerimientoByEstado($estado->nombre))); ?>

                    </a>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php endif; ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/partials/index.blade.php ENDPATH**/ ?>