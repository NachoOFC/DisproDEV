<?php $__env->startComponent('mail::message'); ?>
# Reclamo en guia de despacho <?php echo e($guiaDespacho->folio); ?>

# Centro: <?php echo e($guiaDespacho->nombre_centro); ?>

# Empresa: <?php echo e($guiaDespacho->razon_social_receptor); ?>


Se ha generado por parte del cliente <?php echo e($user->name); ?>(<?php echo e($user->email); ?>) un reclamo para el siguiente producto: <br />
<?php echo e($producto->detalle); ?> con la siguiente observacion: <?php echo e($observacion); ?>. <br />

<?php if(isset($mensaje)): ?>
Adicionalmente el cliente dejo el siguiente mensaje: <br />
<?php echo e($mensaje); ?>

<?php endif; ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/emails/estado_pago/reclamo.blade.php ENDPATH**/ ?>