<?php $__env->startSection('title', 'Cuenta Corriente | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl">Cuenta Corriente</h3>
            <div class="card-body">
                <div class="container mt-2">
                    <div class="table-responsive">
                        <table id="datatable" class="table table-sm">
                            <thead>
                                <tr>
                                    <th scope="col" rowspan="2">Centro</th>
                                    <?php for($i = 1; $i < 13; $i++): ?>
                                        <th class="text-center border" colspan="3"><?php echo e(ucfirst(\Carbon\Carbon::createFromDate(2020, $i, 1)->monthName)); ?></th>
                                    <?php endfor; ?>
                                </tr>
                                <tr>
                                    <?php for($i = 1; $i < 13; $i++): ?>
                                        <th>Real ($)</th>
                                        <th>Presupuesto ($)</th>
                                        <th>Desviacion ($)</th>
                                    <?php endfor; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php for($i = 0; $i < count($cmi); $i++): ?>
                                    <tr>
                                        <th scope="row"><?php echo e($cmi[$i]['centro']->nombre); ?></th>
                                        <?php for($j = 0; $j < 12; $j++): ?>
                                            <td class="text-right"><?php echo e(number_format($real = ($cmi[$i]['totales']->has($j+1) ? $cmi[$i]['totales'][$j + 1][$j + 1] : 0), 0)); ?></td>
                                            <td class="text-right"><?php echo e(number_format($presupuesto = (isset($cmi[$i]['iniciales'][$j]) ? $cmi[$i]['iniciales'][$j]->monto : 0), 0)); ?></td>
                                            <td class="text-right"><?php echo e(number_format($mes = $presupuesto - $real, 0)); ?></td>
                                        <?php endfor; ?>
                                    </tr>
                                <?php endfor; ?>
                            </tbody>
                            <tfoot>
                                    <th scope="row">Total</th>
                                    <?php for($j = 0; $j < 12; $j++): ?>
                                        <td class="text-right"><?php echo e(number_format($totalGasto[$j], 0)); ?></td>
                                        <td class="text-right"><?php echo e(number_format($totalPresupuesto[$j], 0)); ?></td>
                                        <td class="text-right"><?php echo e(number_format($totalPresupuesto[$j] - $totalGasto[$j], 0)); ?></td>
                                    <?php endfor; ?>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/presupuesto/index/cmi.blade.php ENDPATH**/ ?>