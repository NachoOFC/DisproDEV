<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('compass.home')); ?>"><i class="fas fa-home mr-2"></i>Inicio</a>
</li>
<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownRequerimientos" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-clipboard-list mr-2"></i>
        Ordenes de Pedido
    </a>
    <div class="dropdown-menu">
        <a class="dropdown-item" href="<?php echo e(route('pedidos.indexEmpresa')); ?>">Lista</a>
        <?php if(Auth::user()->userable->name === 'Compras'): ?>
            <a class="dropdown-item" href="<?php echo e(route('compass.pedidos.verificar')); ?>">Verificar</a>
        <?php endif; ?>
        <?php if(Auth::user()->userable->name === 'Despacho'): ?>
            <a class="dropdown-item" href="<?php echo e(route('compass.pedidos.cajasIndex')); ?>">Armar Cajas</a>
            <a class="dropdown-item" href="<?php echo e(route('compass.pedidos.programarDespachos')); ?>">Programar Despachos</a>
            <a class="dropdown-item" href="<?php echo e(route('compass.pedidos.despachar')); ?>">Despachar</a>
        <?php endif; ?>
    </div>
</li>
<?php if(Auth::user()->userable->name === 'Compras'): ?>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownProductos" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-th-list mr-2"></i>
            Productos
        </a>
        <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo e(route('productos.index')); ?>">Lista</a>
            <a class="dropdown-item"
               href="<?php echo e(route('productos.indexEmpresa')); ?>">Lista por Empresa</a>
            <a class="dropdown-item" href="<?php echo e(route('productos.create')); ?>">Nuevo</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo e(route('productos.cargaMasivaView')); ?>">Carga Masiva</a>
            <a class="dropdown-item" href="<?php echo e(route('productos.asignacionMasivaView')); ?>">Asignacion masiva</a>
        </div>
    </li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownCentros" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-route mr-2"></i>
            Puntos de Abastecimientos
        </a>
        <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo e(route('abastecimientos.index')); ?>">Lista</a>
            <a class="dropdown-item" href="<?php echo e(route('abastecimientos.create')); ?>">Nuevo</a>
        </div>
    </li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownCentros" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-address-card mr-2"></i>
            Bodegueros
        </a>
        <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo e(route('bodegueros.index')); ?>">Lista</a>
            <a class="dropdown-item" href="<?php echo e(route('bodegueros.create')); ?>">Nuevo</a>
        </div>
    </li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownHoldings" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-building mr-2"></i>
            Holdings
        </a>
        <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo e(route('holdings.index')); ?>">Lista</a>
            <a class="dropdown-item" href="<?php echo e(route('holdings.create')); ?>">Nuevo</a>
            <a class="dropdown-item" href="<?php echo e(route('usuarios.index', 'h')); ?>">Usuarios</a>
        </div>
    </li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownEmpresas" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-industry mr-2"></i>
            Empresas
        </a>
        <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo e(route('empresas.index')); ?>">Lista</a>
            <a class="dropdown-item" href="<?php echo e(route('empresas.create')); ?>">Nuevo</a>
            <a class="dropdown-item" href="<?php echo e(route('usuarios.index', 'e')); ?>">Usuarios</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item"
                href="<?php echo e(route('horarios.create')); ?>">Asignar Horarios</a>
        </div>
    </li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownCentros" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-warehouse mr-2"></i>
            Centros de Cultivos
        </a>
        <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo e(route('centros.index')); ?>">Lista</a>
            <a class="dropdown-item" href="<?php echo e(route('centros.create')); ?>">Nuevo</a>
            <a class="dropdown-item" href="<?php echo e(route('usuarios.index', 'c')); ?>">Usuarios</a>
        </div>
    </li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownUsuarios" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-users mr-2"></i>
            Usuarios
        </a>
        <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo e(route('usuarios.index', 'r')); ?>">Usuarios Compass</a>
            <a class="dropdown-item" href="<?php echo e(route('usuarios.index')); ?>">Todos los Usuarios</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo e(route('register')); ?>">Nuevo Usuario</a>
            <a class="dropdown-item" href="<?php echo e(route('usuarios.asignar')); ?>">Asignar Usuario</a>
        </div>
    </li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownReportes" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-list mr-2"></i>
            Reportes
        </a>
        <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo e(route('reportes.productosCantidad')); ?>">Productos Por Cantidad</a>
            <a class="dropdown-item" href="<?php echo e(route('reportes.packs')); ?>">Generar Packs</a>
            <a class="dropdown-item" href="<?php echo e(route('reportes.productos')); ?>">Rebaja de Productos</a>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('cargarFolios')); ?>">
            <i class="fas fa-sign-in-alt mr-2"></i>
            Cargar Folios
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('requerimiento.cargaMasiva')); ?>">
            <i class="fas fa-sign-in-alt mr-2"></i>
            Importar Requerimientos
        </a>
    </li>
<?php endif; ?>
<?php /**PATH /var/www/html/mline-siger/resources/views/compass/menu.blade.php ENDPATH**/ ?>