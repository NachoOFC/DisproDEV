<?php $__env->startSection('title', 'Lista de Centros | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\Empresa)): ?>
  <?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php elseif(Auth::user()->userable instanceof \App\CompassRole): ?>
    <?php $__env->startSection('home-route', route('compass.home')); ?>
<?php endif; ?>

<?php $__env->startSection('nav-menu'); ?>
  <?php if((Auth::user()->userable instanceof \App\Empresa)): ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php elseif(Auth::user()->userable instanceof \App\CompassRole): ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
  <div class="container">
    <div class="card">
      <h3 class="card-header font-bold text-xl">Lista de Centros</h3>
      <div class="card-body">
        <div class="container mt-2">
          <div class="table-responsive">
            <table id="datatable" class="table table-sm">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Nombre</th>
                  <th scope="col">Empresa</th>
                  <th scope="col">Estado</th>
                  <th scope="col">Accion</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($loop->index); ?></th>
                    <td><?php echo e($centro->nombre); ?></td>
                    <td><?php echo e($centro->empresa->razon_social); ?></td>
                    <td>
                        <?php echo e(isset($centro->habilitado) ? (($centro->habilitado) ? 'Habilitado' : 'Inhabilitado') : 'Segun Horario'); ?>

                        </td>
                    <td>
                      <a class="btn btn-warning" href="<?php echo e(route('centros.habilitar.get', $centro)); ?>">Cambiar estado</a>
                      <a class="btn btn-primary" href="<?php echo e(route('centros.edit', $centro)); ?>"><i class="fas fa-edit"></i></a>
                      <delete-btn-component action="<?php echo e(route('centros.destroy', $centro)); ?>"></delete-btn-component>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jmonagas/Projects/mline-siger/resources/views/centro/index.blade.php ENDPATH**/ ?>