<?php $__env->startSection('title', 'Lista de Usuarios | Mline SIGER'); ?>

<?php if(Auth::user()->userable instanceof \App\CompassRole): ?>
    <?php $__env->startSection('home-route', route('compass.home')); ?>
<?php else: ?>
    <?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php endif; ?>

<?php $__env->startSection('nav-menu'); ?>
<?php if(Auth::user()->userable instanceof \App\CompassRole): ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl">Lista de Usuarios</h3>
            <div class="card-body">
                <table id="datatable" class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">E-mail</th>
                            <th scope="col">Tipo de Usuario</th>
                            <th scope="col">Accion</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->index); ?></th>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e(($user->userable_id !== null) ? substr($user->userable_type, 4) : 'Sin Asignar'); ?></td>
                                <td>
                                    <a class="btn btn-primary" href="<?php echo e(route('usuarios.edit', $user)); ?>"><i class="fas fa-edit"></i></a>
                                    <delete-btn-component action="<?php echo e(route('usuarios.destroy', $user)); ?>"></delete-btn-component>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jmonagas/Projects/mline-siger/resources/views/usuario/index.blade.php ENDPATH**/ ?>