<?php $__env->startSection('title', 'Lista de Pedidos | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
    <?php $__env->startSection('home-route', route('compass.home')); ?>
<?php else: ?>
    <?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php endif; ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php if(Auth::user()->userable instanceof \App\CompassRole): ?>
        <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
    <a class="btn btn-secondary" style="color: #fff;"  href="<?php echo e(route('compass.home')); ?>"><i class='fas fa-arrow-alt-circle-left'></i></a>


        <div class="card">
            <h3 class="card-header font-bold text-xl">Lista de Ordenes de Pedido</h3>
            <div class="card-body">
                <div class="container mt-2">
                    <?php $__env->startComponent('partials.index',
                            ['type' => 2,
                            'empresas' =>
                            $empresas]); ?>
                        <?php if (isset($__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54)): ?>
<?php $component = $__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54; ?>
<?php unset($__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/alogis_dev/resources/views/requerimiento/index/empresa.blade.php ENDPATH**/ ?>