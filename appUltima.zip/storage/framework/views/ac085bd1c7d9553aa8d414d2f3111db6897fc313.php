<?php $__env->startSection('title', 'Manejar Presupuesto | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl">Manejar Presupuestos</h3>
            <div class="card-body">
                <create-presupuesto-component :items='<?php echo json_encode($centros, 15, 512) ?>' action="<?php echo e(route('presupuesto.store')); ?>"></create-presupuesto-component>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/presupuesto/create.blade.php ENDPATH**/ ?>