<?php $__env->startSection('title', 'Armar Cajas'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

  <?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('main'); ?>
    <div class="container">
      <div class="card">
        <h3 class="card-header font-bold text-xl">Armar Cajas</h3>
        <div class="card-body">
          <form action="<?php echo e(route('compass.pedidos.armarCaja', $requerimiento)); ?>" method="POST" class="container mt-2">
            <?php echo csrf_field(); ?>

            <div class="row">
              <div class="col">
                <div class="card">
                  <div class="card-body">
                    <div class="row">
                      <div class="col text-right">Empresa:</div>
                      <div class="col font-bold"><?php echo e($requerimiento->centro->empresa->razon_social); ?></div>
                    </div>
                    <div class="row">
                      <div class="col text-right">Giro:</div>
                      <div class="col font-bold"><?php echo e($requerimiento->centro->empresa->giro); ?></div>
                    </div>
                    <div class="row">
                      <div class="col text-right">RUT Empresa:</div>
                      <div class="col font-bold"><?php echo e($requerimiento->centro->empresa->rut); ?></div>
                    </div>
                    <div class="row">
                      <div class="col text-right">Centro:</div>
                      <div class="col font-bold"><?php echo e($requerimiento->centro->nombre); ?></div>
                    </div>
                    <div class="row">
                      <div class="col text-right">Comuna:</div>
                      <div class="col font-bold"><?php echo e($requerimiento->centro->comuna); ?></div>
                    </div>
                    <div class="row">
                      <div class="col text-right">Ciudad:</div>
                      <div class="col font-bold"><?php echo e($requerimiento->centro->ciudad); ?></div>
                    </div>
                    <div class="row">
                      <div class="col text-right">Direccion:</div>
                      <div class="col font-bold"><?php echo e($requerimiento->centro->direccion); ?></div>
                    </div>
                    <div class="row">
                      <div class="col text-right">Nombre del Pedido:</div>
                      <div class="col font-bold"><?php echo e($requerimiento->nombre); ?></div>
                    </div>
                    <div class="row">
                      <div class="col text-right">Fecha de Creacion:</div>
                      <div class="col font-bold"><?php echo e($requerimiento->created_at); ?></div>
                    </div>
                    <div class="row">
                      <div class="col text-right">Bodeguero Responsable:</div>
                      <div class="col font-bold">
                        <select class="form-control form-control-sm w-50" name="bodeguero">
                          <?php $__currentLoopData = $bodegueros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bodeguero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bodeguero->id); ?>"><?php echo e($bodeguero->nombre); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
                    <div class="row mt-4">
                      <div class="col-md-2">
                        <agregar-producto-caja
                          :productos='<?php echo json_encode($productos, 15, 512) ?>' action="<?php echo e(route('requerimiento.productos.agregar', $requerimiento)); ?>"></agregar-producto-caja>
                      </div>
                      <div class="col-md-2 offset-md-4">
                        <button type="submit" class="btn btn-success">Armar</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <table id="datatable-requerimiento" class="table">
              <thead>
                <tr>
                  <th scope="col">SKU</th>
                  <th scope="col">Detalle</th>
                  <th scope="col">Cantidad Solicitada</th>
                  <th scope="col">Cantidad a despachar</th>
                  <th scope="col">Fecha de Vencimiento</th>
                  <th scope="col">Observaciones</th>
                  <th scope="col">Acciones</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $requerimiento->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <input type="hidden" value="<?php echo e($producto); ?>" name="productos[]"/>
                    <td><?php echo e($producto->sku); ?></td>
                    <td><?php echo e($producto->detalle); ?></td>
                    <td><?php echo e($producto->pivot->cantidad); ?></td>
                    <td><input class="form-control form-control-sm" name="real[]" value="<?php echo e($producto->pivot->cantidad); ?>" type="text"></td>
                    <td><input type="date" class="form-control form-control-sm" name="vencimiento[]" min="<?php echo e(\Carbon\Carbon::now()->addDays(10)); ?>"></td>
                    <td><input class="form-control form-control-sm" type="text" name="observaciones[]" value="<?php echo e($producto->pivot->observacion); ?>"></td>
                    <td>
                      <a class="btn btn-primary" href="<?php echo e(route('cajas.cambiar', [$requerimiento, $producto])); ?>">
                        <i class="fas fa-undo"></i>
                      </a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </form>
        </div>
      </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jmonagas/Projects/mline-siger/resources/views/compass/cajas_show.blade.php ENDPATH**/ ?>