<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

  <?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <v-card class="m-5 p-2">
        <v-card-title>Resumen de productos</v-card-title>

        <v-card-text>
            <v-btn
                class="mb-2"
                depressed
                color="indigo"
                href="<?php echo e(route('bidones.create')); ?>"
            >
                Crear producto
            </v-btn>
            <index-component :headers="[
                { text: 'Codigo', value: 'codigo' },
                { text: 'Nombre', value: 'nombre' },
                { text: 'Acciones', value: 'actions' }
                ]" :items='<?php echo json_encode($bidones, 15, 512) ?>'></index-component>
        </v-card-text>
    </v-card>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/control/bidon/index.blade.php ENDPATH**/ ?>