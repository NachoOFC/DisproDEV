<?php $__env->startSection('title', 'Lista de Pedidos | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

    <?php $__env->startSection('nav-menu'); ?>
        <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('main'); ?>
        <div class="container">
        <a class="btn btn-secondary" style="color: #fff;"  href="<?php echo e(route('compass.pedidos.cajasIndex')); ?>"><i class='fas fa-arrow-alt-circle-left'></i></a>


            <div class="card">
                <h3 class="card-header font-bold text-xl">Lista de Ordenes de Pedido</h3>
                <div class="card-body">
                    <div class="container mt-2">
                        <div class="table-responsive">
                            <table id="datatable" class="table table-sm table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">Nombre Pedido</th>
                                        <th scope="col">Centro</th>
                                        <th scope="col">Folio</th>
                                        <th scope="col">Fecha de solicitud</th>
                                        <th scope="col">Estado</th>
                                        <th scope="col">Fecha de estado</th>
                                        <th scope="col">Ultima Actualizacion</th>
                                        <th scope="col">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $requerimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($requerimiento->nombre); ?></td>
                                            <td><?php echo e($requerimiento->centro->nombre); ?></td>
                                            <td><?php echo e($requerimiento->folio ?? "S/F"); ?></td>
                                            <td><?php echo e($requerimiento->created_at); ?></td>
                                            <td><?php echo e($requerimiento->estado); ?></td>
                                            <td><?php echo e($requerimiento->estadoActual->created_at ?? $requerimiento->updated_at); ?></td>
                                            <td><?php echo e($requerimiento->updated_at); ?></td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <?php if( $requerimiento->estado === 'RECIBIDO CON OBSERVACIONES'): ?>
                                                        <a
                                                            class="btn btn-outline-info"
                                                            href="<?php echo e(route(
                                                                     'rechazos.show',
                                                                     $requerimiento)); ?>"
                                                        >
                                                            Ver Observaciones
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if( $requerimiento->estado === 'DESPACHADO'): ?>
                                                        <modal-btn-component
                                                            title="Orden de Pedido"
                                                            :message='[
                                                                   { data: <?php echo json_encode([
                                                                           "nombre" => $requerimiento->transporte->nombre_chofer, "rut" => $requerimiento->transporte->rut_chofer, "contacto" => $requerimiento->transporte->contacto
                                                                           ]) ?>
                                                                   , type: "Object", keys: ["nombre",
                                                                   "rut", "contacto"]}
                                                                   ]'
                                                        >
                                                            Ver Transporte
                                                        </modal-btn-component>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/requerimiento/index/logistica.blade.php ENDPATH**/ ?>