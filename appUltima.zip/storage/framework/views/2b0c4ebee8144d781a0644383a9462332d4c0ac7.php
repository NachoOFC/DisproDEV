<?php $__env->startSection('title', 'Cierre Estado de Pago | MLine SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
<?php $__env->startSection('home-route', route('compass.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('home-route', route('cliente.home')); ?>
<?php $__env->startSection('nav-menu'); ?>
<?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>


<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="card">
        <h3 class="card-header font-bold text-xl">Cierre Estado de Pago</h3>
        <div class="card-body">
            <div class="d-flex flex-row mb-2">
            </div>
            <div class="container mt-2">
                <form action="<?php echo e(route("estado_pago_generar_cierre")); ?>" method="POST" accept-charset="utf-8">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="form-group col-md-3 d-flex flex-col">
                            <label class="" for="inicio">Inicio:</label>
                            <input class="form-control" name="inicio" type="date" />
                        </div>
                        <div class="form-group col-md-3 d-flex flex-col">
                            <label class="" for="fin">Fin:</label>
                            <input class="form-control" name="fin" type="date" />
                        </div>

                        <?php if(isset($empresas)): ?>
                        <div class="form-group col-md-4 d-flex flex-col">
                            <label for="empresa">Empresa:</label>
                            <span>
                                <autoselect :items='<?php echo json_encode($empresas, 15, 512) ?>' item-text="razon_social" item-value="id" name="empresa"></autoselect>
                            </span>
                        </div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" name="closed" value="0" class="btn btn-primary my-5">Exportar a Excel</button>

                    <?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
                    <button type="submit" name="closed" value="1" class="btn btn-primary my-5">Generar Cierrre</button>
                    <?php endif; ?>
                </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/estado_pago/cierre.blade.php ENDPATH**/ ?>