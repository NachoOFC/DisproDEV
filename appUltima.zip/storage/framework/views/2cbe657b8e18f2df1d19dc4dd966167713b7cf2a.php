<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header font-bold text-xl"> Importar Requerimiento</div>
            <div class="card-body">
                <form action="<?php echo e(route('requerimientos.importar')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="form-group row">
                        <label class="col-sm-2" for="centro">Centro:</label>
                        <span class="col-sm-6">
                            <filter-select-component :options='<?php echo json_encode($centros, 15, 512) ?>' label="nombre" value="id" name="centro"></filter-select-component>
                            <p class="text-muted">Obligatorio</p>
                        </span>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2" for="archivo">Archivo:</label>
                        <span class="col-sm-6">
                            <input type="file" class="form-control" name="archivo">
                            <p class="text-muted">Obligatorio</p>
                        </span>
                    </div>

                    <button class="btn bg-orange-500 hover:bg-orange-700 text-white">Importar</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/alogis_dev/resources/views/requerimiento/carga_masiva.blade.php ENDPATH**/ ?>