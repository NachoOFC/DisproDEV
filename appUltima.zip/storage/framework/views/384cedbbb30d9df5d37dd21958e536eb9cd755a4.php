<?php $__env->startSection('title', 'Notificaciones'); ?>

<?php $__env->startSection('home-route', $home); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make($menu, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header font-bold text-xl">Notificaciones</div>
            <div class="card-body">
                <div class="row">
                    <div class="container">
                        <?php $__env->startComponent('partials.notifications', ['notifications' => $notifications]); ?>
                        <?php if (isset($__componentOriginalb056292f683580c93d8eacac7c0eaea24503b848)): ?>
<?php $component = $__componentOriginalb056292f683580c93d8eacac7c0eaea24503b848; ?>
<?php unset($__componentOriginalb056292f683580c93d8eacac7c0eaea24503b848); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header font-bold">Notificaciones Antiguas</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('SearchNotification')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-row">
                                <label class="col-md col-form-label" for="año">Seleccione el año:</label>
                                <div class="col-md">
                                    <select class="form-control" name="year" id="year">
                                        <?php for($i = date("Y") - 20; $i < date("Y") + 20; $i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <label class="col-md col-form-label" for="">Seleccione el mes:</label>
                                <div class="col-md">
                                    <select class="form-control" name="mes">
                                        <?php for($i = 1; $i < 13; $i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e(DateTime::createFromFormat('!m', $i)->format('F')); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md"><button class="btn btn-primary">Buscar</button></div>
                            </div>
                        </form>
                        <?php if(isset($oldNotifications)): ?>
                            <?php $__env->startComponent('partials.notifications', ['notifications' => $oldNotifications]); ?>
                            <?php if (isset($__componentOriginalb056292f683580c93d8eacac7c0eaea24503b848)): ?>
<?php $component = $__componentOriginalb056292f683580c93d8eacac7c0eaea24503b848; ?>
<?php unset($__componentOriginalb056292f683580c93d8eacac7c0eaea24503b848); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/alogis_dev/resources/views/notifications.blade.php ENDPATH**/ ?>