<?php $__env->startSection('title', 'Crear Orden de Pedido | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

  <?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('main'); ?>
    <div class="card">
      <h3 class="card-header font-bold text-xl"><?php echo e($empresa->razon_social); ?>: Editar orden de pedido</h3>
      <crear-requerimiento-component
        :index-productos='<?php echo json_encode($productos, 15, 512) ?>'
        presupuesto="<?php echo e($presupuesto); ?>"
        :empresa='<?php echo json_encode($empresa, 15, 512) ?>'
        :centro='<?php echo json_encode($centro, 15, 512) ?>'
        nombre="<?php echo e($requerimiento->nombre); ?>"
        :libreria='<?php echo json_encode($productosLibreria, 15, 512) ?>'
        action="<?php echo e($requerimiento->updateRoute); ?>"
      ></crear-requerimiento-component>
    </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/requerimiento/edit.blade.php ENDPATH**/ ?>