<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

  <?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <v-card class="m-5 p-2">
        <v-card-title>Resumen de <?php echo e($title); ?></v-card-title>

        <v-card-text>
            <v-btn class="mb-2" depressed color="indigo" href="<?php echo e($createRoute); ?>">Crear <?php echo e($title); ?></v-btn>
            <index-component :headers="[
                { text: 'Fecha de Ingreso', value: 'fecha_ingreso' },
                { text: 'Detalle', value: 'bidon.nombre' },
                { text: 'Cantidad', value: 'qty' },
                { text: 'Acciones', value: 'actions' }
                ]" :items='<?php echo json_encode($items, 15, 512) ?>'></index-component>
        </v-card-text>
    </v-card>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/control/generic/index.blade.php ENDPATH**/ ?>