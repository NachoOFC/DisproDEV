<?php $__env->startSection('title', 'Libreria de Ordenes | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">

        <div class="card">
            <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Libreria de Ordenes de Pedido</h3>
            <div class="card-body">
                <div class="container table-responsive">
                    <table id="datatable" class="table table-sm">
                        <thead>
                            <tr>
                                <th scope="col">Nombre</th>
                                <th scope="col">Ver</th>
                                <th scope="col">Usar</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $requerimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($requerimiento->pivot->nombre); ?></td>
                                    <td>
                                                <modal-btn-component
                                                    title="Orden de Pedido"
                                                    :message='[
                                                    { data:
                                                    <?php echo json_encode($requerimiento->productos, 15, 512) ?>,
                                                    type: "Array", keys: ["sku",
                                                    "detalle", "precio",
                                                    "pivot", "total"], pivot: "cantidad"},
                                                    { data: <?php echo json_encode(["total" => "$" . number_format($requerimiento->getTotal()) ], 15, 512) ?>, type: "Object", keys: ["total"]}
                                                    ]'>Detalles</modal-btn-component>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('requerimientos.edit',
                                    $requerimiento)); ?>" class="btn
                                    btn-info">Usar</a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/requerimiento/libreria_index.blade.php ENDPATH**/ ?>