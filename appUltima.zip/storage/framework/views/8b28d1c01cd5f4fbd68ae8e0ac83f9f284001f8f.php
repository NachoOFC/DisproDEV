<?php $__env->startSection('title', 'Asignar Usuarios | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl">Asignar Usuarios</h3>
            <div class="card-body">
                <form action="<?php echo e(route('usuario.asignacion')); ?>" method="POST" accept-charset="utf-8">
                    <?php echo csrf_field(); ?>

                    <div class="form-group form-row">
                        <label class="col-md-4 col-form-label text-md-right" for="name">Nombre:</label>
                        <div class="col-md-6">
                            <input type="text" readonly class="form-control-plaintext" value="<?php echo e($user->name); ?>">
                        </div>
                    </div>

                    <div class="form-group form-row">
                        <label class="col-md-4 col-form-label text-md-right" for="name">E-mail:</label>
                        <div class="col-md-6">
                            <input type="text" readonly class="form-control-plaintext" value="<?php echo e($user->email); ?>">
                        </div>
                    </div>

                    <div class="form-group form-row">
                        <label class="col-md-4 col-form-label text-md-right" for="asignacion">Asignacion:</label>
                        <div class="col-md-6">
                            <select class="form-control" name="asignacion">
                                <?php $__currentLoopData = $asignacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($obj->id); ?>"><?php echo e($obj->nombre ?? $obj->razon_social ?? $obj->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <input type="hidden" value="<?php echo e($user->id); ?>" name="userId"/>
                    <input type="hidden" value="<?php echo e(get_class($asignacion[0])); ?>" name="asignacionType"/>

                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Asignar')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mline-siger/resources/views/usuario/asignacion.blade.php ENDPATH**/ ?>