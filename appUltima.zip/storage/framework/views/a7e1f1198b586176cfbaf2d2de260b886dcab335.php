<?php $__env->startSection('title', 'Lista de Puntos de Abastecimiento | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Lista de Puntos de Abastecimiento</h3>
            <div class="card-body">
                <div class="container mt-2">
                    <div class="table-responsive">
                        <table id="datatable" class="table table-sm">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nombre</th>
                                    <th scope="col">Comuna</th>
                                    <th scope="col">Ciudad</th>
                                    <th scope="col">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $abastecimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abastecimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->index); ?></th>
                                        <td><?php echo e($abastecimiento->nombre); ?></td>
                                        <td><?php echo e($abastecimiento->comuna); ?></td>
                                        <td><?php echo e($abastecimiento->ciudad); ?></td>
                                        <td>
                                            <a class="btn btn-primary" href="<?php echo e(route('abastecimientos.edit', $abastecimiento)); ?>"><i class="fas fa-edit"></i></a>
                                            <delete-btn-component action="<?php echo e(route('abastecimientos.destroy', $abastecimiento)); ?>"></delete-btn-component>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/alogis_dev/resources/views/abastecimiento/index.blade.php ENDPATH**/ ?>