<?php $__env->startSection('title', 'Cliente SIGER'); ?>

<?php $__env->startSection('home-route', route('cliente.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Dashboard</h3>
            <div class="card-body">
                <div class="card mb-3">
                    <div class="card-body">
                        <h3 class="font-bold text-md border-bottom mb-3"><i class="fas fa-tachometer-alt"></i> Accesos Directo:</h3>
                        <div class="d-flex flex-row justify-content-around align-items-end">
                            <?php if(Auth::user()->userable instanceof \App\Centro): ?>
                                <a class="btn btn-outline-primary" href="<?php echo e(route('requerimientos.create')); ?>">
                                    <i class="fas fa-tasks"></i>
                                    Nueva Orden de Pedido
                                </a>
                            <?php else: ?>
                                <a class="btn btn-outline-primary" href="<?php echo e(route('pedidos.validar')); ?>">
                                    <i class="fas fa-tasks"></i>
                                    Validar Ordenes de Pedido
                                </a>
                            <?php endif; ?>
                            <?php if(Auth::user()->userable instanceof \App\Centro): ?>
                                <a class="btn btn-outline-primary" href="<?php echo e(route('libreria.index')); ?>">
                                    <i class="fas fa-list"></i>
                                    Libreria Ordenes de Pedido
                                </a>
                            <?php else: ?>
                                <a class="btn btn-outline-primary" href="<?php echo e(route('presupuesto.create')); ?>">
                                    <i class="fas fa-wallet"></i>
                                    Cargar Presupuesto
                                </a>
                            <?php endif; ?>
                            <?php if(Auth::user()->userable instanceof \App\Centro): ?>
                                <a class="btn btn-outline-primary" href="<?php echo e(route('presupuesto.indexCentro')); ?>">
                                    <i class="fas fa-money-check-alt"></i>
                                    Revisar Cuenta Corriente
                                </a>
                            <?php else: ?>
                                <a class="btn btn-outline-primary" href="<?php echo e(route('presupuesto.indexEmpresa')); ?>">
                                    <i class="fas fa-money-check-alt"></i>
                                    Revisar Cuenta Corriente
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="card-body">
                        <h3 class="font-bold text-md border-bottom mb-3"><i class="fas fa-chart-line"></i> Reportes:</h3>
                        <div class="container">
                            <div class="row">
                                <?php switch(get_class(Auth::user()->userable)):
                                case ('App\Centro'): ?>
                                <div class="col">
                                    <?php $__env->startComponent('partials.index',
                                        ['type' => 0,
                                        'requerimientos' =>
                                        Auth::user()->userable
                                        ->requerimientos()
                                        ->whereYear('created_at', date("Y"))
                                        ->whereMonth('created_at', date("m"))
                                        ->get()]); ?>
                                    <?php if (isset($__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54)): ?>
<?php $component = $__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54; ?>
<?php unset($__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                                </div>
                                <?php break; ?>
                                <?php case ('App\Empresa'): ?>
                                <div class="col">
                                    <?php $__env->startComponent('partials.index',
                                        ['type' => 1,
                                        'centros' =>
                                        Auth::user()->userable->centros()->get()]); ?>
                                    <?php if (isset($__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54)): ?>
<?php $component = $__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54; ?>
<?php unset($__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                                </div>
                                <?php break; ?>
                                <?php case ('App\Holding'): ?>
                                <div class="col">
                                    <?php $__env->startComponent('partials.index',
                                        ['type' => 2,
                                        'empresas' =>
                                        Auth::user()->userable->empresas()->get()]); ?>
                                    <?php if (isset($__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54)): ?>
<?php $component = $__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54; ?>
<?php unset($__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                                </div>
                                <?php break; ?>
                            <?php endswitch; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h3 class="font-bold text-md border-bottom mb-3"><i class="fas fa-bell"></i> Ultimas Notificaciones:</h3>
                        <?php $__env->startComponent('partials.notifications', ['notifications' => $notifications]); ?>
                        <?php if (isset($__componentOriginalb056292f683580c93d8eacac7c0eaea24503b848)): ?>
<?php $component = $__componentOriginalb056292f683580c93d8eacac7c0eaea24503b848; ?>
<?php unset($__componentOriginalb056292f683580c93d8eacac7c0eaea24503b848); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jmonagas/Projects/mline-siger/resources/views/cliente/home.blade.php ENDPATH**/ ?>