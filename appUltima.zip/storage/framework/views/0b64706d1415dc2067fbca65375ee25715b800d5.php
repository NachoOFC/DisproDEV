<?php $__env->startSection('title', 'Lista de Ordenes | Mline SIGER'); ?>

<?php if((Auth::user()->userable instanceof \App\CompassRole)): ?>
    <?php $__env->startSection('home-route', route('compass.home')); ?>
    <?php else: ?>
        <?php $__env->startSection('home-route', route('cliente.home')); ?>
        <?php endif; ?>

        <?php $__env->startSection('nav-menu'); ?>
            <?php if(Auth::user()->userable instanceof \App\CompassRole): ?>
                <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('cliente.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('main'); ?>
            <div class="container">

                <div class="card">
                    <h3 class="card-header font-bold text-xl">Datos de Orden de Pedido</h3>
                    <div class="card-body">
                        <div class="row">
                            <div class="card col-md mx-2">
                                <div class="card-body">
                                    <h4 class="card-title text-xl font-bold border-bottom">Datos Empresa</h4>
                                    <b>Razon Social: </b><?php echo e($empresa->razon_social); ?><b class="ml-3">RUT Empresa: </b><?php echo e($empresa->rut); ?> <br />
                                    <b>Giro: </b><?php echo e($empresa->giro); ?> <br />
                                    <b>Direccion: </b><?php echo e($empresa->direccion); ?> <br />
                                </div>
                            </div>
                            <div class="card col-md mx-2">
                                <div class="card-body">
                                    <h4 class="card-title text-xl font-bold border-bottom">Datos Centro</h4>
                                    <b>Nombre: </b><?php echo e($centro->nombre); ?> <br>
                                    <b>Direccion: </b><?php echo e($centro->direccion); ?> <br>
                                    <b>Comuna: </b><?php echo e($centro->comuna); ?> <br>
                                    <b>Ciudad: </b><?php echo e($centro->ciudad); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="card col-md mx-2">
                                <div class="card-body">
                                    <h4 class="card-title text-xl font-bold border-bottom">Datos Orden de Pedido</h4>
                                    <b>Nombre: </b><?php echo e($requerimiento->nombre); ?> <br />
                                    <b>Folio: </b><?php echo e($requerimiento->folio ?? $requerimiento->id); ?> <br />
                                    <b>Estado: </b><?php echo e($requerimiento->estado); ?> <br />
                                    <b>Total: </b>$ <?php echo e(number_format($requerimiento->getTotal(), 0)); ?> <br />
                                    <b>Fecha de Creacion: </b><?php echo e($requerimiento->created_at); ?> <br />
                                    <b>Ultima Actualizacion: </b><?php echo e($requerimiento->updated_at); ?> <br />
                                    <a href="<?php echo e(route('descargarGuias', $requerimiento)); ?>" class="btn btn-primary">Guia de despacho</a>
                                </div>
                            </div>
                            <div class="card col-md mx-2">
                                <div class="card-body">
                                    <h4 class="card-title text-xl font-bold
                                    border-bottom">Datos de Transporte</h4>
                                    <b>Nombre Transportista: </b>
                                    <?php echo e($requerimiento->transporte->nombre ?? 'Sin Despachar'); ?> <br />
                                    <b>RUT Transportista: </b>
                                    <?php echo e($requerimiento->transporte->rut ??
                                    'Sin Despachar'); ?> <br />
                                    <b>Contacto Transportista: </b>
                                    <?php echo e($requerimiento->transporte->contacto
                                    ?? 'Sin Despachar'); ?> <br />
                                </div>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="container table-responsive">
                                <table id="datatable" class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th scope="col">SKU</th>
                                            <th scope="col">Detalle</th>
                                            <th scope="col">Precio Unitario ($)</th>
                                            <th scope="col">Fecha de Vencimiento</th>
                                            <th scope="col">Cantidad Solicitada</th>
                                            <th scope="col">Cantidad Despachada</th>
                                            <th scope="col">Subtotal ($)</th>
                                            <th scope="col">Observaciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($producto->sku); ?></td>
                                                <td><?php echo e($producto->detalle); ?></td>
                                                <td><?php echo e(number_format($producto->pivot->precio)); ?></td>
                                                <td><?php echo e($producto->pivot->fecha_vencimiento ?? 'N/A'); ?></td>
                                                <td><?php echo e($producto->pivot->cantidad ?? 0); ?></td>
                                                <td><?php echo e($producto->pivot->real ?? 'Sin Despachar'); ?></td>
                                                <td><?php echo e(number_format($producto->pivot->precio * ($producto->pivot->real ?? $producto->pivot->cantidad))); ?></td>
                                                <td><?php echo e($producto->pivot->observacion ?? 'Sin Observaciones'); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mline-siger/resources/views/requerimiento/show.blade.php ENDPATH**/ ?>