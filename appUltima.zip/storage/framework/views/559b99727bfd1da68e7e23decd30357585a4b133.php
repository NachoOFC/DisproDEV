<?php $__env->startSection('title', 'Armar Cajas'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl">Armar Cajas</h3>
            <div class="card-body">
                <form action="<?php echo e(route('cajas.reemplazar', $requerimiento)); ?>" method="POST" class="container mt-2">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="form-group row">
                        <label class="col-md-2 col-form-label text-right" for="productoReemplazado">Producto a Reemplazar:</label>
                        <div class="col-md">
                            <input type="hidden" readonly name="productoReemplazadoId" value="<?php echo e($producto->id); ?>" class="form-control-plaintext"/>
                            <input type="text" readonly name="productoReemplazado" value="<?php echo e($producto->detalle); ?>" class="form-control-plaintext"/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-2 col-form-label text-right" for="nuevoProducto">Producto de Reemplazo:</label>
                        <div class="col-md">
                            <filterable-select-component :options='<?php echo json_encode($productos, 15, 512) ?>'></filterable-select-component>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2 mx-auto">
                            <button type="submit" class="btn btn-success">Reemplazar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/compass/cajas_reemplazar.blade.php ENDPATH**/ ?>