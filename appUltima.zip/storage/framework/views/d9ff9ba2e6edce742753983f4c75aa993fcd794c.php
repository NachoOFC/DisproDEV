<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
  <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
  <div class="container">
    <div class="card">
      <h3 class="card-header font-bold text-xl">Lista de Productos</h3>
      <div class="card-body">
        <div class="container mt-2">
        <div class="table-responsive">
            <table id="datatable" class="table table-sm">
              <thead>
                <tr>
                  <th scope="col">SKU</th>
                  <th scope="col">Detalle</th>
                  <th scope="col">Precio Costo</th>
                  <th scope="col">Accion</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($producto->sku); ?></td>
                    <td><?php echo e($producto->detalle); ?></td>
                    <td><?php echo e($producto->costo); ?></td>
                    <td>
                      <a class="btn btn-primary" href="<?php echo e(route('productos.edit', $producto)); ?>"><i class="fas fa-edit"></i></a>
                      <delete-btn-component action="<?php echo e(route('productos.destroy', $producto)); ?>"></delete-btn-component>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mline-siger/resources/views/compass/producto/index.blade.php ENDPATH**/ ?>