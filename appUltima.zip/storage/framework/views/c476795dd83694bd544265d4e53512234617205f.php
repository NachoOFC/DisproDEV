<?php $__env->startSection('title', 'Lista de Usuarios | Mline SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <h3 class="card-header font-bold text-xl">Lista de Usuarios</h3>
            <div class="card-body">
                <table id="datatable" class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">E-mail</th>
                            <th scope="col">Holding</th>
                            <th scope="col">Empresa</th>
                            <th scope="col">Centro</th>
                            <th scope="col">Compass</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->index); ?></th>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><a class="btn btn-primary" href="<?php echo e(route('usuario.asignar', ['userId' => $user, 'tipo' => 'h'])); ?>">Asignar a Holding</a></td>
                                <td><a class="btn btn-primary" href="<?php echo e(route('usuario.asignar', ['userId' => $user, 'tipo' => 'e'])); ?>">Asignar a Empresa</a></td>
                                <td><a class="btn btn-primary" href="<?php echo e(route('usuario.asignar', ['userId' => $user, 'tipo' => 'c'])); ?>">Asignar a Centro</a></td>
                                <td><a class="btn btn-primary" href="<?php echo e(route('usuario.asignar', ['userId' => $user, 'tipo' => 'r'])); ?>">Asignar a Compass</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php if(\Session::has('msg')): ?>
    <?php
        $msg = \Session::get('msg');
    ?>
    <?php $__env->startSection('js'); ?>
        <script charset="utf-8">
            (Swal.fire({
                title: '<?php echo e($msg['meta']['title']); ?>',
                html: '<?php echo $msg['meta']['message']; ?>',
                icon: 'success'
            }))();

        </script>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/usuario/asignar.blade.php ENDPATH**/ ?>