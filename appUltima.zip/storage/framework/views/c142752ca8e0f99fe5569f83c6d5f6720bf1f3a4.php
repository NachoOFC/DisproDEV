<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header font-bold text-xl">
                <?php echo e(Auth::user()->getNombreRelacionado()); ?>: Cargar Folios
            </div>
            <div class="card-body">
                <div class="form-row">
                    <form class="col" action="<?php echo e(route('folios.store')); ?>" method="POST" accept-charset="utf-8">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label class="col-md-2" for="desde">Desde:</label>
                            <div class="col-md-6">
                                <input type="text" name="desde" class="form-control"/>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-2" for="hasta">Hasta:</label>
                            <div class="col-md-6">
                                <input type="text" name="hasta" class="form-control"/>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-10">
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                    </form>
                    <div class="col">
                        <strong>Folios Disponibles:</strong>
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th scope="col">Desde</th>
                                    <th scope="col">Hasta</th>
                                    <th scope="col">Ultimo Folio</th>
                                    <th scope="col">Disponibles</th>
                                    <th scope="col">Fecha de Creacion</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <?php if(isset($folio)): ?>
                                        <td><?php echo e($folio->desde); ?></td>
                                        <td><?php echo e($hasta = $folio->hasta); ?></td>
                                        <td><?php echo e($folio->ultimo); ?></td>
                                        <td><?php echo e($hasta - $folio->ultimo); ?></td>
                                        <td><?php echo e($folio->created_at); ?></td>
                                    <?php else: ?>
                                        <div class="alert alert-dark">No hay folios cargados</div>
                                    <?php endif; ?>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php if(\Session::has('msg')): ?>
    <?php
        $msg = \Session::get('msg');
    ?>
    <?php $__env->startSection('js'); ?>
        <script charset="utf-8">
            (Swal.fire({
                title: '<?php echo e($msg['meta']['title']); ?>',
                html: '<?php echo $msg['meta']['msg']; ?>',
                icon: 'success'
            }))();

        </script>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/alogis_dev/resources/views/compass/cargar_folios.blade.php ENDPATH**/ ?>