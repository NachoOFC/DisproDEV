<?php $__env->startSection('title', 'Compass SIGER'); ?>

<?php $__env->startSection('home-route', route('compass.home')); ?>

<?php $__env->startSection('nav-menu'); ?>
    <?php echo $__env->make('compass.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header font-bold text-xl"><?php echo e(Auth::user()->getNombreRelacionado()); ?>: Dashboard</div>
            <div class="card-body">
                <div class="card mb-3">
                    <div class="card-body">
                        <h3 class="font-bold text-md border-bottom mb-3"><i class="fas fa-tachometer-alt"></i> Accesos Directo:</h3>
                        <div class="d-flex flex-row justify-content-around align-items-end">
                            <?php if(Auth::user()->userable->name == 'Compras'): ?>
                                <a class="btn btn-outline-primary" href="<?php echo e(route('compass.pedidos.verificar')); ?>">
                                    <i class="fas fa-tasks"></i>
                                    Verificar Ordenes de Pedido
                                </a>
                                <a class="btn btn-outline-primary" href="<?php echo e(route('cargarFolios')); ?>">
                                    <i class="fas fa-tasks"></i>
                                    Cargar Folios
                                </a>
                                <a class="btn btn-outline-primary" href="<?php echo e(route('usuarios.index')); ?>">
                                    <i class="fas fa-tasks"></i>
                                    Lista de Usuarios
                                </a>
                            <?php else: ?>
                                <a class="btn btn-outline-primary" href="<?php echo e(route('compass.pedidos.cajasIndex')); ?>">
                                    <i class="fas fa-tasks"></i>
                                    Armar Cajas
                                </a>
                                <a class="btn btn-outline-primary" href="<?php echo e(route('compass.pedidos.programarDespachos')); ?>">
                                    <i class="fas fa-tasks"></i>
                                    Programar Despachos
                                </a>
                                <a class="btn btn-outline-primary" href="<?php echo e(route('compass.pedidos.despachar')); ?>">
                                    <i class="fas fa-tasks"></i>
                                    Despachar
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="card-body">
                        <h3 class="font-bold text-md border-bottom mb-3"><i class="fas fa-chart-line"></i> Reportes:</h3>
                        <?php $__env->startComponent('partials.index',
                            ['type' => 2,
                            'empresas' =>
                            \App\Empresa::all()]); ?>
                        <?php if (isset($__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54)): ?>
<?php $component = $__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54; ?>
<?php unset($__componentOriginal31b527c5c9bb384c3973a4f9d3277538f8b4ff54); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h3 class="font-bold text-md border-bottom mb-3"><i class="fas fa-bell"></i> Ultimas Notificaciones:</h3>
                        <?php $__env->startComponent('partials.notifications', ['notifications' => $notifications]); ?>
                        <?php if (isset($__componentOriginalb056292f683580c93d8eacac7c0eaea24503b848)): ?>
<?php $component = $__componentOriginalb056292f683580c93d8eacac7c0eaea24503b848; ?>
<?php unset($__componentOriginalb056292f683580c93d8eacac7c0eaea24503b848); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/compass/home.blade.php ENDPATH**/ ?>