<?php $__env->startComponent('mail::message'); ?>
# Actualizado el estado de pago para la guia de despacho <?php echo e($guiaDespacho->folio); ?>



<?php $__currentLoopData = $tipoObservaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoObservacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
Esta actualizacion se realizo bajo el concepto de <?php echo e($tipoObservacion->nombre); ?>. <br />
Los productos con este concepto ahora son: <br />
|SKU|DETALLE|DESPACHADO|RECIBIDO|GENERA NOTA CREDITO|
|---|---|---|---|---|
<?php $__currentLoopData = $guiaDespacho->getProductosByObservacionesId($tipoObservacion->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
|<?php echo e($producto->sku); ?>|<?php echo e($producto->detalle); ?>|<?php echo e($producto->pivot->real); ?>|<?php echo e($producto->pivot->cantidad_recibido); ?>|<?php echo e($producto->pivot->genera_nc ? "SI" : "NO"); ?>|
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->startComponent('mail::button', ['url' => route("estado_pago_concepto", ["guiaDespacho" => $guiaDespacho, "concepto" => $concepto])]); ?>
Puede ver el detalle aqui.
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH /home/mlinecl/siger_prod/resources/views/emails/estado_pago/actualizado.blade.php ENDPATH**/ ?>