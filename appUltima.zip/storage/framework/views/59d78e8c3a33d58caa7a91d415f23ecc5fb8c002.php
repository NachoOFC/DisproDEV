<?php if($type === 0): ?>
    <table id="datatable" class="table">
        <thead>
            <tr>
                <th scope="col">Folio</th>
                <th scope="col">Nombre</th>
                <th scope="col">Estado</th>
                <?php if((Auth::user()->userable instanceof \App\Centro)): ?>
                    <th scope="col">Libreria</th>   
                <?php endif; ?>
                <th scope="col">Fecha de Creacion</th>
                <th scope="col">Accion</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $requerimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo e(route('pedidos.show',
                        $requerimiento)); ?>"><?php echo e($requerimiento->folio ?? $requerimiento->id); ?></a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.show', $requerimiento)); ?>"><?php echo e($requerimiento->nombre); ?></a>
                    </td>
                    <td><?php echo e($requerimiento->estado); ?></td>
                    <?php if((Auth::user()->userable instanceof \App\Centro)): ?>
                        <td>
                            <agregar-libreria-component
                                action="<?php echo e(route('libreria.editar', $requerimiento)); ?>"
                                :library='<?php echo json_encode(Auth::user()->hasRequerimiento($requerimiento), 15, 512) ?>'></agregar-libreria-component>
                        </td>
                    <?php endif; ?>
                    <td><?php echo e($requerimiento->created_at); ?></td>
                    <td>
                        <div class="btn-group" role="group">
                            <modal-btn-component
                                title="Orden de Pedido"
                                :message='[
                                { data:
                                <?php echo json_encode($requerimiento->productos, 15, 512) ?>,
                                type: "Array", keys: ["sku",
                                "detalle",
                                "pivot"], pivot: "cantidad"},
                                { data: <?php echo json_encode(["total" => "$" . number_format($requerimiento->getTotal()) ], 15, 512) ?>, type: "Object", keys: ["total"]}
                                ]'>Ver Orden de Pedido</modal-btn-component>
                            <?php if(Auth::user()->userable instanceof \App\Centro): ?>
                                <?php if( $requerimiento->estado === 'DESPACHADO'): ?>
                                    <a class="btn btn-success" href="<?php echo e(route('pedidos.entregado', $requerimiento)); ?>">Recibido</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if( $requerimiento->estado === 'DESPACHADO'): ?>
                                <modal-btn-component
                                    title="Orden de Pedido"
                                    :message='[
                                    { data: <?php echo json_encode([
                                    "nombre" => $requerimiento->transporte->nombre, "rut" => $requerimiento->transporte->rut, "contacto" => $requerimiento->transporte->contacto
                                    ]) ?>
                                    , type: "Object", keys: ["nombre",
                                    "rut", "contacto"]}
                                    ]'>Ver Transporte</modal-btn-component>
                                <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($type === 1): ?>
    <table id="datatable" class="table table-sm">
        <thead>
            <tr>
                <th scope="col" rowspan="2">#</th>
                <th scope="col" rowspan="2">Nombre</th>
                <th class="text-center" scope="row" colspan="7">Estados</th>
                <th scope="col" rowspan="2">Ver Todos</th>
            </tr>
            <tr>
                <th scope="col">Esperando Validacion</th>
                <th scope="col">Validado</th>
                <th scope="col">En Procesamiento</th>
                <th scope="col">En Bodega</th>
                <th scope="col">Despachado</th>
                <th scope="col">Entregado</th>
                <th scope="col">Rechazado</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->index + 1); ?></th>
                    <td><?php echo e($centro->nombre); ?></td>
                    <td>
                        <a href="<?php echo e(route('pedidos.centro', ['centro' => $centro->id, 'estado' => '0'])); ?>">
                            <?php echo e(count($centro->requerimientos()->where('estado', 'ESPERANDO VALIDACION')->get())); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.centro', ['centro' => $centro->id, 'estado' => '1'])); ?>">
                            <?php echo e(count($centro->requerimientos()->where('estado', 'VALIDADO')->get())); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.centro', ['centro' => $centro->id, 'estado' => '2'])); ?>">
                            <?php echo e(count($centro->requerimientos()->where('estado', 'EN PROCESAMIENTO')->get())); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.centro', ['centro' => $centro->id, 'estado' => '3'])); ?>">
                            <?php echo e(count($centro->requerimientos()->where('estado', 'EN BODEGA')->get())); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.centro', ['centro' => $centro->id, 'estado' => '4'])); ?>">
                            <?php echo e(count($centro->requerimientos()->where('estado', 'DESPACHADO')->get())); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.centro', ['centro' => $centro->id, 'estado' => '5'])); ?>">
                            <?php echo e(count($centro->requerimientos()->where('estado', 'ENTREGADO')->get())); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.centro', ['centro' => $centro->id, 'estado' => '6'])); ?>">
                            <?php echo e(count($centro->requerimientos()->where('estado', 'RECHAZADO')->get())); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.centro', ['centro' => $centro->id, 'estado' => '7'])); ?>">
                            Ver Todas
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($type === 2): ?>
    <table id="datatable" class="table table-sm">
        <thead>
            <tr>
                <th scope="col" rowspan="2">#</th>
                <th scope="col" rowspan="2">Nombre</th>
                <th class="text-center" scope="row" colspan="7">Estados</th>
                <th scope="col" rowspan="2">Ver Todos</th>
            </tr>
            <tr>
                <th scope="col">Esperando Validacion</th>
                <th scope="col">Validado</th>
                <th scope="col">En Procesamiento</th>
                <th scope="col">En Bodega</th>
                <th scope="col">Despachado</th>
                <th scope="col">Entregado</th>
                <th scope="col">Rechazado</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->index + 1); ?></th>
                    <td><?php echo e($empresa->razon_social); ?></td>
                    <td>
                        <a href="<?php echo e(route('pedidos.indexCentro', ['empresa' => $empresa, 'estado' => 0])); ?>">
                            <?php echo e(count($empresa->getRequerimientoByEstado('ESPERANDO VALIDACION'))); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.indexCentro', ['empresa' => $empresa, 'estado' => 1])); ?>">
                            <?php echo e(count($empresa->getRequerimientoByEstado('VALIDADO'))); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.indexCentro', ['empresa' => $empresa, 'estado' => 2])); ?>">
                            <?php echo e(count($empresa->getRequerimientoByEstado('EN PROCESAMIENTO'))); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.indexCentro', ['empresa' => $empresa, 'estado' => 3])); ?>">
                            <?php echo e(count($empresa->getRequerimientoByEstado('EN BODEGA'))); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.indexCentro', ['empresa' => $empresa, 'estado' => 4])); ?>">
                            <?php echo e(count($empresa->getRequerimientoByEstado('DESPACHADO'))); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.indexCentro', ['empresa' => $empresa, 'estado' => 5])); ?>">
                            <?php echo e(count($empresa->getRequerimientoByEstado('ENTREGADO'))); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.indexCentro', ['empresa' => $empresa, 'estado' => 6])); ?>">
                            <?php echo e(count($empresa->getRequerimientoByEstado('RECHAZADO'))); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pedidos.indexCentro', ['empresa' => $empresa, 'estado' => 7])); ?>">
                            Ver Todos
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>
<?php /**PATH /var/www/html/mline-siger/resources/views/partials/index.blade.php ENDPATH**/ ?>